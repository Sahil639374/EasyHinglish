package com.easyhinglish.translator.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.provider.Settings
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.easyhinglish.translator.model.OcrTextBlock
import com.easyhinglish.translator.model.ScreenOcrCapture
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class EasyHinglishAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event listening kept lightweight; screen is captured on explicit user 1-tap.
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    suspend fun captureScreenBitmapWithRetry(): Bitmap? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        val firstAttempt = takeScreenshotOnce()
        if (firstAttempt.bitmap != null) return firstAttempt.bitmap
        if (firstAttempt.errorCode == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) {
            delay(500L)
            return takeScreenshotOnce().bitmap
        }
        return null
    }

    private data class ScreenshotAttempt(val bitmap: Bitmap?, val errorCode: Int = 0)

    private suspend fun takeScreenshotOnce(): ScreenshotAttempt {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return ScreenshotAttempt(null, -1)
        }
        return suspendCancellableCoroutine { cont ->
            runCatching {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    mainExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshot: ScreenshotResult) {
                            val hwBuffer = screenshot.hardwareBuffer
                            val colorSpace = screenshot.colorSpace
                            val swBitmap = try {
                                val wrapped = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                                val copied = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                                wrapped?.recycle()
                                copied
                            } catch (_: Throwable) {
                                null
                            } finally {
                                runCatching { hwBuffer.close() }
                            }
                            if (cont.isActive) {
                                cont.resume(ScreenshotAttempt(swBitmap, 0))
                            } else {
                                swBitmap?.recycle()
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            if (cont.isActive) {
                                cont.resume(ScreenshotAttempt(null, errorCode))
                            }
                        }
                    }
                )
            }.onFailure {
                if (cont.isActive) {
                    cont.resume(ScreenshotAttempt(null, -2))
                }
            }
        }
    }

    fun captureVisibleTextBlocks(): ScreenOcrCapture? {
        val root = runCatching { rootInActiveWindow }.getOrNull() ?: return null
        val (screenW, screenH) = getScreenDimensions()
        val statusCutoff = (screenH * 0.036f).toInt()
        val latinRegex = Regex("[A-Za-z]{2,}")
        val seenTexts = LinkedHashSet<String>()
        val blocks = mutableListOf<OcrTextBlock>()

        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 28) return
            val raw = (node.text ?: node.contentDescription)?.toString()
                ?.replace(Regex("\\s+"), " ")
                ?.trim()
                .orEmpty()
            if (raw.length >= 2 && latinRegex.containsMatchIn(raw) && !seenTexts.contains(raw)) {
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                if (bounds.width() > 8 && bounds.height() > 8 &&
                    bounds.bottom > 0 && bounds.top < screenH &&
                    !(bounds.top < statusCutoff && raw.length <= 16)
                ) {
                    seenTexts.add(raw)
                    blocks.add(
                        OcrTextBlock(
                            text = raw,
                            left = bounds.left.coerceIn(0, screenW - 1),
                            top = bounds.top.coerceIn(0, screenH - 1),
                            right = bounds.right.coerceIn(1, screenW),
                            bottom = bounds.bottom.coerceIn(1, screenH)
                        )
                    )
                }
            }
            val count = node.childCount
            for (i in 0 until count) {
                val child = runCatching { node.getChild(i) }.getOrNull()
                if (child != null) {
                    traverse(child, depth + 1)
                }
            }
        }

        runCatching {
            traverse(root, 0)
        }

        if (blocks.isEmpty()) return null
        return ScreenOcrCapture(
            bitmapWidth = screenW,
            bitmapHeight = screenH,
            blocks = blocks
        )
    }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width().coerceAtLeast(320) to b.height().coerceAtLeast(320)
        } else {
            val pt = Point()
            @Suppress("DEPRECATION")
            wm.defaultDisplay?.getRealSize(pt)
            if (pt.x > 0 && pt.y > 0) pt.x to pt.y else 1080 to 2400
        }
    }

    companion object {
        @Volatile
        var instance: EasyHinglishAccessibilityService? = null

        fun isReady(): Boolean = instance != null

        fun isEnabledInSettings(context: Context): Boolean {
            if (instance != null) return true
            val expected = ComponentName(context, EasyHinglishAccessibilityService::class.java)
            val flat = expected.flattenToString()
            val shortFlat = expected.flattenToShortString()
            val enabled = runCatching {
                Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                )
            }.getOrNull().orEmpty()
            return enabled.split(':').any {
                it.equals(flat, ignoreCase = true) || it.equals(shortFlat, ignoreCase = true)
            }
        }
    }
}
