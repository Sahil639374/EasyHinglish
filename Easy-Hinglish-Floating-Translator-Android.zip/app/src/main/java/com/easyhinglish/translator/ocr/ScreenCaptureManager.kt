package com.easyhinglish.translator.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ScreenCaptureManager(private val context: Context) {
    private var recognizerInstance: TextRecognizer? = null
    private val recognizer: TextRecognizer
        get() = recognizerInstance ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .also { recognizerInstance = it }

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width().coerceAtLeast(320) to bounds.height().coerceAtLeast(320)
        } else {
            val pt = Point()
            @Suppress("DEPRECATION")
            wm.defaultDisplay?.getRealSize(pt)
            if (pt.x > 0 && pt.y > 0) {
                pt.x to pt.y
            } else {
                val m = context.resources.displayMetrics
                m.widthPixels.coerceAtLeast(720) to m.heightPixels.coerceAtLeast(1280)
            }
        }
    }

    suspend fun captureAndRecognizeText(projection: MediaProjection): String {
        val (width, height) = getScreenDimensions()
        val density = context.resources.displayMetrics.densityDpi.coerceAtLeast(160)

        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        var virtualDisplay: VirtualDisplay? = null

        try {
            virtualDisplay = projection.createVirtualDisplay(
                "EasyHinglishOcrCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                null
            )

            var image: Image? = null
            for (attempt in 0 until 8) {
                delay(if (attempt == 0) 260L else 100L)
                image = imageReader.acquireLatestImage()
                if (image != null) break
            }

            if (image == null) {
                throw IllegalStateException("Could not capture screen frame. Try again.")
            }

            val bitmap = try {
                val imgW = image.width.coerceAtLeast(1)
                val imgH = image.height.coerceAtLeast(1)
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride.coerceAtLeast(4)
                val rowStride = plane.rowStride
                val rowPadding = (rowStride - pixelStride * imgW).coerceAtLeast(0)
                val rawWidth = imgW + rowPadding / pixelStride
                val rawBitmap = Bitmap.createBitmap(rawWidth, imgH, Bitmap.Config.ARGB_8888)
                rawBitmap.copyPixelsFromBuffer(buffer)
                val safeW = minOf(imgW, rawBitmap.width)
                val safeH = minOf(imgH, rawBitmap.height)
                if (rawBitmap.width == safeW && rawBitmap.height == safeH) {
                    rawBitmap
                } else {
                    Bitmap.createBitmap(rawBitmap, 0, 0, safeW, safeH).also {
                        rawBitmap.recycle()
                    }
                }
            } finally {
                image.close()
            }

            val inputImage = InputImage.fromBitmap(bitmap, 0)
            return suspendCancellableCoroutine { cont ->
                recognizer.process(inputImage)
                    .addOnSuccessListener { visionText ->
                        val recognized = visionText.text.replace(Regex("\\s+"), " ").trim()
                        if (cont.isActive) cont.resume(recognized)
                    }
                    .addOnFailureListener { ex ->
                        if (cont.isActive) cont.resumeWithException(ex)
                    }
            }
        } finally {
            runCatching { virtualDisplay?.release() }
            runCatching { imageReader.close() }
        }
    }

    fun close() {
        runCatching { recognizerInstance?.close() }
        recognizerInstance = null
    }
}
