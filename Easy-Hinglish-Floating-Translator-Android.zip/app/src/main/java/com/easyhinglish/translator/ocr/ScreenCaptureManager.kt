package com.easyhinglish.translator.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.view.WindowManager
import com.easyhinglish.translator.model.OcrTextBlock
import com.easyhinglish.translator.model.ScreenOcrCapture
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ScreenCaptureManager(private val context: Context) {
    private var recognizerInstance: TextRecognizer? = null
    private val recognizer: TextRecognizer
        get() = recognizerInstance ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .also { recognizerInstance = it }

    private var activeProjection: MediaProjection? = null
    private var persistentDisplay: VirtualDisplay? = null
    private var persistentReader: ImageReader? = null
    private var readerWidth: Int = 0
    private var readerHeight: Int = 0

    private fun getScreenDimensions(): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width().coerceAtLeast(320) to bounds.height().coerceAtLeast(320)
        } else {
            val pt = Point()
            @Suppress("DEPRECATION")
            wm.defaultDisplay?.getRealSize(pt)
            if (pt.x > 0 && pt.y > 0) {
                pt.x to pt.y
            } else {
                val m = context.resources.displayMetrics
                m.widthPixels.coerceAtLeast(720) to m.heightPixels.coerceAtLeast(1280)
            }
        }
    }

    @Synchronized
    private fun ensurePersistentSurface(projection: MediaProjection, width: Int, height: Int): ImageReader {
        if (activeProjection === projection &&
            persistentDisplay != null &&
            persistentReader != null &&
            readerWidth == width &&
            readerHeight == height
        ) {
            return persistentReader!!
        }

        releasePersistentSurface()

        val density = context.resources.displayMetrics.densityDpi.coerceAtLeast(160)
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        val display = projection.createVirtualDisplay(
            "EasyHinglishOcrCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            null
        )
        activeProjection = projection
        persistentReader = reader
        persistentDisplay = display
        readerWidth = width
        readerHeight = height
        return reader
    }

    @Synchronized
    fun releasePersistentSurface() {
        runCatching { persistentDisplay?.release() }
        runCatching { persistentReader?.close() }
        persistentDisplay = null
        persistentReader = null
        activeProjection = null
        readerWidth = 0
        readerHeight = 0
    }

    private suspend fun captureBitmap(projection: MediaProjection): Bitmap {
        val (width, height) = getScreenDimensions()
        val reader = ensurePersistentSurface(projection, width, height)

        // Drain stale buffered images if any, then wait for a fresh frame
        runCatching {
            while (true) {
                val old = reader.acquireLatestImage() ?: break
                old.close()
            }
        }

        var image: Image? = null
        for (attempt in 0 until 10) {
            delay(if (attempt == 0) 200L else 90L)
            image = runCatching { reader.acquireLatestImage() }.getOrNull()
            if (image != null) break
        }

        if (image == null) {
            throw IllegalStateException("Could not capture fresh screen frame")
        }

        return try {
            val imgW = image.width.coerceAtLeast(1)
            val imgH = image.height.coerceAtLeast(1)
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride.coerceAtLeast(4)
            val rowStride = plane.rowStride
            val rowPadding = (rowStride - pixelStride * imgW).coerceAtLeast(0)
            val rawWidth = imgW + rowPadding / pixelStride
            val rawBitmap = Bitmap.createBitmap(rawWidth, imgH, Bitmap.Config.ARGB_8888)
            rawBitmap.copyPixelsFromBuffer(buffer)
            val safeW = minOf(imgW, rawBitmap.width)
            val safeH = minOf(imgH, rawBitmap.height)
            if (rawBitmap.width == safeW && rawBitmap.height == safeH) {
                rawBitmap
            } else {
                Bitmap.createBitmap(rawBitmap, 0, 0, safeW, safeH).also {
                    rawBitmap.recycle()
                }
            }
        } finally {
            image.close()
        }
    }

    private suspend fun runMlKitOcr(bitmap: Bitmap): Text {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        return suspendCancellableCoroutine { cont ->
            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    if (cont.isActive) cont.resume(visionText)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    suspend fun recognizeBlocksFromBitmap(bitmap: Bitmap): ScreenOcrCapture {
        val bmpW = bitmap.width.coerceAtLeast(1)
        val bmpH = bitmap.height.coerceAtLeast(1)
        val statusBarCutoff = (bmpH * 0.036f).toInt()
        val latinWordRegex = Regex("[A-Za-z]{2,}")

        return try {
            val visionText = runMlKitOcr(bitmap)
            val blocks = mutableListOf<OcrTextBlock>()
            for (block in visionText.textBlocks) {
                val rect = block.boundingBox ?: continue
                val cleanText = block.text.replace(Regex("\\s+"), " ").trim()
                if (cleanText.length < 2) continue
                if (!latinWordRegex.containsMatchIn(cleanText)) continue
                if (rect.top < statusBarCutoff && cleanText.length <= 16) continue
                blocks.add(
                    OcrTextBlock(
                        text = cleanText,
                        left = rect.left.coerceIn(0, bmpW - 1),
                        top = rect.top.coerceIn(0, bmpH - 1),
                        right = rect.right.coerceIn(1, bmpW),
                        bottom = rect.bottom.coerceIn(1, bmpH)
                    )
                )
            }
            ScreenOcrCapture(
                bitmapWidth = bmpW,
                bitmapHeight = bmpH,
                blocks = blocks
            )
        } finally {
            runCatching { bitmap.recycle() }
        }
    }

    suspend fun captureScreenBlocks(projection: MediaProjection): ScreenOcrCapture {
        val bitmap = captureBitmap(projection)
        return recognizeBlocksFromBitmap(bitmap)
    }

    suspend fun captureAndRecognizeText(projection: MediaProjection): String {
        val capture = captureScreenBlocks(projection)
        return capture.blocks.joinToString("\n") { it.text }.trim()
    }

    fun close() {
        releasePersistentSurface()
        runCatching { recognizerInstance?.close() }
        recognizerInstance = null
    }
}
