package com.easyhinglish.translator.model

enum class TranslationMode(val label: String) {
    EASY_HINDI("Easy Hindi"),
    ROMAN_HINDI("Roman Hindi"),
    HINGLISH("Hinglish")
}

data class DictionaryEntry(
    val id: String,
    val sourceWord: String,
    val easyWord: String,
    val devanagariEasy: String = "",
    val enabled: Boolean = true
)

data class TranslationResult(
    val sourceText: String,
    val translatedText: String,
    val mode: TranslationMode,
    val appliedRules: List<String>
)

data class OcrTextBlock(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)

data class ScreenOcrCapture(
    val bitmapWidth: Int,
    val bitmapHeight: Int,
    val blocks: List<OcrTextBlock>
)

data class TranslatedOverlayBlock(
    val sourceText: String,
    val rawHindiText: String,
    val translatedText: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)
