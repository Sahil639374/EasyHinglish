package com.easyhinglish.translator.model

enum class TranslationMode(val label: String) {
    EASY_HINDI("Easy Hindi"),
    ROMAN_HINDI("Roman Hindi"),
    HINGLISH("Hinglish")
}

data class DictionaryEntry(
    val id: String,
    val sourceWord: String,
    val easyWord: String,
    val devanagariEasy: String = "",
    val enabled: Boolean = true
)

data class TranslationResult(
    val sourceText: String,
    val translatedText: String,
    val mode: TranslationMode,
    val appliedRules: List<String>
)
