package com.easyhinglish.translator.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.easyhinglish.translator.R
import com.easyhinglish.translator.data.DictionaryStore
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.service.FloatingBubbleService
import com.easyhinglish.translator.translation.TranslatorEngine
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var dictionaryStore: DictionaryStore
    private lateinit var translatorEngine: TranslatorEngine
    private var currentMode = TranslationMode.HINGLISH
    private var pendingOcrAfterPermission = false

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startFloatingBubbleService()
            if (pendingOcrAfterPermission) {
                pendingOcrAfterPermission = false
                launchScreenOcrPermission()
            }
        } else {
            pendingOcrAfterPermission = false
            Toast.makeText(this, "Please allow notifications to keep floating bubble active", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rootLayout = findViewById<View>(R.id.rootLayout)
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        dictionaryStore = DictionaryStore(this)
        translatorEngine = TranslatorEngine()
        currentMode = dictionaryStore.getDefaultMode()

        val pageTranslate = findViewById<View>(R.id.pageTranslate)
        val pageDictionary = findViewById<View>(R.id.pageDictionary)
        val pageSettings = findViewById<View>(R.id.pageSettings)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            pageTranslate.visibility = if (item.itemId == R.id.nav_translate) View.VISIBLE else View.GONE
            pageDictionary.visibility = if (item.itemId == R.id.nav_dictionary) View.VISIBLE else View.GONE
            pageSettings.visibility = if (item.itemId == R.id.nav_settings) View.VISIBLE else View.GONE
            true
        }

        setupTranslateTab()
        setupDictionaryTab()
        setupSettingsTab()
    }

    private fun setupTranslateTab() {
        val etInput = findViewById<EditText>(R.id.etEnglishInput)
        val tvResult = findViewById<TextView>(R.id.tvTranslatedResult)
        val btnEasy = findViewById<Button>(R.id.btnMainEasy)
        val btnRoman = findViewById<Button>(R.id.btnMainRoman)
        val btnHinglish = findViewById<Button>(R.id.btnMainHinglish)
        val btnPaste = findViewById<Button>(R.id.btnPasteTranslate)
        val btnTranslate = findViewById<Button>(R.id.btnTranslate)
        val btnCopy = findViewById<Button>(R.id.btnCopyResult)
        val btnClear = findViewById<Button>(R.id.btnClearResult)
        val btnBubble = findViewById<Button>(R.id.btnLaunchBubble)

        fun styleModeBtn(btn: Button, active: Boolean) {
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (active) 0xFF2563EB.toInt() else 0xFFE2E8F0.toInt()
            )
            btn.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF0F172A.toInt())
        }

        fun updateModeButtons() {
            styleModeBtn(btnEasy, currentMode == TranslationMode.EASY_HINDI)
            styleModeBtn(btnRoman, currentMode == TranslationMode.ROMAN_HINDI)
            styleModeBtn(btnHinglish, currentMode == TranslationMode.HINGLISH)
        }
        updateModeButtons()

        fun runTranslate() {
            val text = etInput.text.toString().trim()
            if (text.isEmpty()) return
            tvResult.text = "Translating..."
            scope.launch {
                try {
                    val res = withContext(Dispatchers.IO) {
                        translatorEngine.translate(text, currentMode, dictionaryStore.getEntries())
                    }
                    tvResult.text = res.translatedText
                } catch (ex: Exception) {
                    tvResult.text = "First-time translation needs internet to download free offline Hindi pack."
                }
            }
        }

        btnEasy.setOnClickListener {
            currentMode = TranslationMode.EASY_HINDI
            dictionaryStore.setDefaultMode(currentMode)
            updateModeButtons()
            runTranslate()
        }
        btnRoman.setOnClickListener {
            currentMode = TranslationMode.ROMAN_HINDI
            dictionaryStore.setDefaultMode(currentMode)
            updateModeButtons()
            runTranslate()
        }
        btnHinglish.setOnClickListener {
            currentMode = TranslationMode.HINGLISH
            dictionaryStore.setDefaultMode(currentMode)
            updateModeButtons()
            runTranslate()
        }

        btnPaste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val primary = cm.primaryClip
            val clip = if (primary != null && primary.itemCount > 0) {
                primary.getItemAt(0).coerceToText(this)?.toString().orEmpty()
            } else {
                ""
            }
            if (clip.isNotBlank()) {
                etInput.setText(clip)
                runTranslate()
            } else {
                Toast.makeText(this, "Clipboard empty", Toast.LENGTH_SHORT).show()
            }
        }

        btnTranslate.setOnClickListener { runTranslate() }

        btnCopy.setOnClickListener {
            val out = tvResult.text.toString()
            if (out.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("EasyHinglish", out))
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
            }
        }

        btnClear.setOnClickListener {
            etInput.setText("")
            tvResult.text = ""
        }

        btnBubble.setOnClickListener {
            pendingOcrAfterPermission = false
            ensureOverlayAndStartBubble()
        }
    }

    private fun setupDictionaryTab() {
        val etSource = findViewById<EditText>(R.id.etDictSource)
        val etEasy = findViewById<EditText>(R.id.etDictEasy)
        val btnAdd = findViewById<Button>(R.id.btnAddWord)
        val listContainer = findViewById<LinearLayout>(R.id.dictListContainer)

        fun renderList() {
            listContainer.removeAllViews()
            for (entry in dictionaryStore.getEntries()) {
                val row = layoutInflater.inflate(R.layout.item_dictionary_row, listContainer, false)
                row.findViewById<TextView>(R.id.tvDictPair).text = "${entry.sourceWord} = ${entry.easyWord}"
                row.findViewById<Button>(R.id.btnDeleteDict).setOnClickListener {
                    dictionaryStore.deleteById(entry.id)
                    renderList()
                }
                listContainer.addView(row)
            }
        }
        renderList()

        btnAdd.setOnClickListener {
            val src = etSource.text.toString().trim()
            val easy = etEasy.text.toString().trim()
            if (src.isNotEmpty() && easy.isNotEmpty()) {
                dictionaryStore.addOrUpdate(src, easy)
                etSource.setText("")
                etEasy.setText("")
                renderList()
            }
        }
    }

    private fun setupSettingsTab() {
        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            openOverlaySettings()
        }
        findViewById<Button>(R.id.btnGrantBattery).setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                val opened = runCatching { startActivity(intent); true }.getOrDefault(false)
                if (!opened) {
                    openAppDetailsFallback("Open Battery settings and choose Unrestricted")
                }
            } else {
                Toast.makeText(this, "Battery already unrestricted", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnStartOcrNow).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please allow Display over other apps first", Toast.LENGTH_SHORT).show()
                openOverlaySettings()
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                pendingOcrAfterPermission = true
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return@setOnClickListener
            }
            startFloatingBubbleService()
            launchScreenOcrPermission()
        }

        val prefs = getSharedPreferences("easy_hinglish_prefs", MODE_PRIVATE)
        val lastCrash = prefs.getString("last_crash_log", null).orEmpty()
        val crashCard = findViewById<LinearLayout>(R.id.cardCrashLog)
        if (lastCrash.isNotBlank()) {
            crashCard.visibility = View.VISIBLE
            findViewById<TextView>(R.id.tvCrashLogPreview).text = lastCrash
            findViewById<Button>(R.id.btnCopyCrashLog).setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CrashLog", lastCrash))
                Toast.makeText(this, "Error log copied", Toast.LENGTH_SHORT).show()
            }
            findViewById<Button>(R.id.btnClearCrashLog).setOnClickListener {
                prefs.edit().remove("last_crash_log").apply()
                crashCard.visibility = View.GONE
            }
        }
    }

    private fun openOverlaySettings() {
        val openedSpecific = runCatching {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            true
        }.getOrDefault(false)
        if (!openedSpecific) {
            val openedGeneral = runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                true
            }.getOrDefault(false)
            if (!openedGeneral) {
                openAppDetailsFallback("Allow 'Display over other apps' in App Info")
            }
        }
    }

    private fun openAppDetailsFallback(hint: String) {
        Toast.makeText(this, hint, Toast.LENGTH_LONG).show()
        runCatching {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                }
            )
        }
    }

    private fun launchScreenOcrPermission() {
        runCatching {
            startActivity(Intent(this, MediaProjectionPermissionActivity::class.java))
        }.onFailure {
            Toast.makeText(this, "Could not open screen capture prompt", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ensureOverlayAndStartBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' permission", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startFloatingBubbleService()
    }

    private fun startFloatingBubbleService() {
        val intent = Intent(this, FloatingBubbleService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Toast.makeText(this, "Floating Bubble started!", Toast.LENGTH_SHORT).show()
        }.onFailure {
            Toast.makeText(this, "Could not start Floating Bubble. Check notification & overlay permissions.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        translatorEngine.close()
    }
}
