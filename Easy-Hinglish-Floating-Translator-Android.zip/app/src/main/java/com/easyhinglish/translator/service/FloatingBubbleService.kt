package com.easyhinglish.translator.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.easyhinglish.translator.R
import com.easyhinglish.translator.data.DictionaryStore
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.ocr.ScreenCaptureManager
import com.easyhinglish.translator.translation.TranslatorEngine
import com.easyhinglish.translator.ui.MainActivity
import com.easyhinglish.translator.ui.MediaProjectionPermissionActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class FloatingBubbleService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private lateinit var dictionaryStore: DictionaryStore
    private lateinit var translatorEngine: TranslatorEngine
    private lateinit var screenCaptureManager: ScreenCaptureManager
    private val themedContext by lazy { ContextThemeWrapper(this, R.style.Theme_EasyHinglish) }

    private var bubbleView: View? = null
    private var popupView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var popupParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var currentMode: TranslationMode = TranslationMode.HINGLISH
    private var lastEnglishText: String = ""
    private var isHiddenToNotification = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        dictionaryStore = DictionaryStore(this)
        translatorEngine = TranslatorEngine()
        screenCaptureManager = ScreenCaptureManager(this)
        currentMode = dictionaryStore.getDefaultMode()

        createNotificationChannel()
        if (!startForegroundCompat(withMediaProjection = false)) {
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_SHORT).show()
            stopSelf()
            return
        }
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW_BUBBLE -> {
                isHiddenToNotification = false
                if (bubbleView == null && Settings.canDrawOverlays(this)) {
                    showBubble()
                }
                bubbleView?.visibility = View.VISIBLE
            }
            ACTION_SET_PROJECTION -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA_INTENT)
                }
                if (resultCode == Activity.RESULT_OK && data != null) {
                    if (!startForegroundCompat(withMediaProjection = true)) {
                        Toast.makeText(this, "Screen OCR permission unavailable", Toast.LENGTH_SHORT).show()
                        return START_NOT_STICKY
                    }
                    runCatching {
                        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        mediaProjection?.stop()
                        mediaProjection = mgr.getMediaProjection(resultCode, data)?.apply {
                            registerCallback(object : MediaProjection.Callback() {
                                override fun onStop() {
                                    mediaProjection = null
                                }
                            }, android.os.Handler(android.os.Looper.getMainLooper()))
                        }
                    }.onFailure {
                        Toast.makeText(this, "Could not start screen capture", Toast.LENGTH_SHORT).show()
                        return START_NOT_STICKY
                    }
                    runScreenOcrCapture()
                } else {
                    Toast.makeText(this, "Screen capture permission cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        runCatching { mediaProjection?.stop() }
        translatorEngine.close()
        screenCaptureManager.close()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        popupView?.let { runCatching { windowManager.removeView(it) } }
    }

    private fun startForegroundCompat(withMediaProjection: Boolean): Boolean {
        val notification = buildNotification()
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val type = if (withMediaProjection) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                }
                startForeground(NOTIFICATION_ID, notification, type)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && withMediaProjection) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        }.getOrElse {
            false
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Translator Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_SHOW_BUBBLE },
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bubble_translate)
            .setContentTitle("Easy Hinglish Translator Active")
            .setContentText("Tap bubble over any game or app to translate")
            .setContentIntent(openIntent)
            .addAction(0, "Show Bubble", showIntent)
            .addAction(0, "Close", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun showBubble() {
        if (bubbleView != null || !Settings.canDrawOverlays(this)) return
        val view = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_bubble, null)
        }.getOrNull() ?: return

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 320
        }

        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = initX + dx
                    params.y = initY + dy
                    runCatching { windowManager.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePopup()
                    true
                }
                else -> false
            }
        }

        runCatching {
            windowManager.addView(view, params)
            bubbleView = view
            bubbleParams = params
        }.onFailure {
            Toast.makeText(this, "Could not show floating bubble", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePopup() {
        if (popupView != null) {
            closePopup()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_SHORT).show()
            return
        }

        val view = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_popup, null)
        }.getOrElse {
            Toast.makeText(this, "Could not open translator popup", Toast.LENGTH_SHORT).show()
            return
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90).toInt().coerceAtLeast(300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val btnEasy = view.findViewById<Button>(R.id.btnModeEasy)
        val btnRoman = view.findViewById<Button>(R.id.btnModeRoman)
        val btnHinglish = view.findViewById<Button>(R.id.btnModeHinglish)
        val btnOcr = view.findViewById<Button>(R.id.btnPopupOcr)
        val btnPaste = view.findViewById<Button>(R.id.btnPopupPaste)
        val btnCopy = view.findViewById<Button>(R.id.btnPopupCopy)
        val btnClear = view.findViewById<Button>(R.id.btnPopupClear)
        val btnAgain = view.findViewById<Button>(R.id.btnPopupAgain)
        val btnHide = view.findViewById<ImageButton>(R.id.btnPopupHide)
        val btnClose = view.findViewById<ImageButton>(R.id.btnPopupClose)
        val inputEdit = view.findViewById<EditText>(R.id.etPopupInput)
        val outputText = view.findViewById<TextView>(R.id.tvPopupOutput)

        inputEdit.setText(lastEnglishText)

        fun styleModeBtn(btn: Button, active: Boolean) {
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (active) 0xFF2563EB.toInt() else 0xFFE2E8F0.toInt()
            )
            btn.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF0F172A.toInt())
        }

        fun refreshModeButtons() {
            styleModeBtn(btnEasy, currentMode == TranslationMode.EASY_HINDI)
            styleModeBtn(btnRoman, currentMode == TranslationMode.ROMAN_HINDI)
            styleModeBtn(btnHinglish, currentMode == TranslationMode.HINGLISH)
        }
        refreshModeButtons()

        fun translateNow(source: String) {
            val clean = source.trim()
            if (clean.isEmpty()) return
            lastEnglishText = clean
            outputText.text = "Translating..."
            scope.launch {
                try {
                    val res = withContext(Dispatchers.IO) {
                        translatorEngine.translate(clean, currentMode, dictionaryStore.getEntries())
                    }
                    outputText.text = res.translatedText
                } catch (ex: Exception) {
                    outputText.text = "First-time translation needs internet once to download free offline Hindi pack."
                }
            }
        }

        btnEasy.setOnClickListener {
            currentMode = TranslationMode.EASY_HINDI
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }
        btnRoman.setOnClickListener {
            currentMode = TranslationMode.ROMAN_HINDI
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }
        btnHinglish.setOnClickListener {
            currentMode = TranslationMode.HINGLISH
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }

        btnOcr.setOnClickListener {
            if (mediaProjection == null) {
                closePopup()
                runCatching {
                    val permIntent = Intent(this, MediaProjectionPermissionActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(permIntent)
                }.onFailure {
                    Toast.makeText(this, "Could not request screen capture permission", Toast.LENGTH_SHORT).show()
                }
            } else {
                runScreenOcrCapture()
            }
        }

        btnPaste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val primary = cm.primaryClip
            val clipText = if (primary != null && primary.itemCount > 0) {
                primary.getItemAt(0).coerceToText(this)?.toString().orEmpty()
            } else {
                ""
            }
            if (clipText.isNotBlank()) {
                inputEdit.setText(clipText)
                translateNow(clipText)
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }

        btnCopy.setOnClickListener {
            val translated = outputText.text.toString()
            if (translated.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("EasyHinglish", translated))
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
            }
        }

        btnClear.setOnClickListener {
            lastEnglishText = ""
            inputEdit.setText("")
            outputText.text = ""
        }

        btnAgain.setOnClickListener {
            translateNow(inputEdit.text.toString())
        }

        btnHide.setOnClickListener {
            closePopup()
            isHiddenToNotification = true
            bubbleView?.visibility = View.GONE
            Toast.makeText(this, "Bubble hidden. Tap notification to show again.", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener {
            stopSelf()
        }

        runCatching {
            windowManager.addView(view, params)
            popupView = view
            popupParams = params
        }.onFailure {
            Toast.makeText(this, "Could not open floating popup", Toast.LENGTH_SHORT).show()
        }
    }

    private fun closePopup() {
        popupView?.let { runCatching { windowManager.removeView(it) } }
        popupView = null
        popupParams = null
    }

    private fun runScreenOcrCapture() {
        val projection = mediaProjection ?: return
        scope.launch {
            closePopup()
            bubbleView?.visibility = View.GONE
            delay(250)
            val recognized = try {
                withContext(Dispatchers.IO) {
                    screenCaptureManager.captureAndRecognizeText(projection)
                }
            } catch (ex: Exception) {
                ""
            }
            if (!isHiddenToNotification) {
                bubbleView?.visibility = View.VISIBLE
            }
            if (recognized.isBlank()) {
                Toast.makeText(this@FloatingBubbleService, "No English text found on screen", Toast.LENGTH_SHORT).show()
                return@launch
            }
            lastEnglishText = recognized
            togglePopup()
            val view = popupView ?: return@launch
            view.findViewById<EditText>(R.id.etPopupInput).setText(recognized)
            val outView = view.findViewById<TextView>(R.id.tvPopupOutput)
            outView.text = "Translating..."
            try {
                val result = withContext(Dispatchers.IO) {
                    translatorEngine.translate(recognized, currentMode, dictionaryStore.getEntries())
                }
                outView.text = result.translatedText
            } catch (ex: Exception) {
                outView.text = "First-time translation needs internet once to download free offline Hindi pack."
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "easy_hinglish_overlay_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.easyhinglish.translator.STOP"
        const val ACTION_SHOW_BUBBLE = "com.easyhinglish.translator.SHOW_BUBBLE"
        const val ACTION_SET_PROJECTION = "com.easyhinglish.translator.SET_PROJECTION"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"
    }
}
