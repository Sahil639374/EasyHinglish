package com.easyhinglish.translator.service

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.easyhinglish.translator.R
import com.easyhinglish.translator.data.DictionaryStore
import com.easyhinglish.translator.model.ScreenOcrCapture
import com.easyhinglish.translator.model.TranslatedOverlayBlock
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.ocr.ScreenCaptureManager
import com.easyhinglish.translator.translation.TranslatorEngine
import com.easyhinglish.translator.ui.MainActivity
import com.easyhinglish.translator.ui.MediaProjectionPermissionActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs

class FloatingBubbleService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private lateinit var dictionaryStore: DictionaryStore
    private lateinit var translatorEngine: TranslatorEngine
    private lateinit var screenCaptureManager: ScreenCaptureManager
    private val themedContext by lazy { ContextThemeWrapper(this, R.style.Theme_EasyHinglish) }

    private var bubbleView: View? = null
    private var popupView: View? = null
    private var screenOverlayView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var popupParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var currentMode: TranslationMode = TranslationMode.ROMAN_HINDI
    private var lastEnglishText: String = ""
    private var isHiddenToNotification = false
    private var isCapturing = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        dictionaryStore = DictionaryStore(this)
        translatorEngine = TranslatorEngine()
        screenCaptureManager = ScreenCaptureManager(this)
        currentMode = dictionaryStore.getDefaultMode()

        createNotificationChannel()
        if (!startForegroundCompat(withMediaProjection = false)) {
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_SHORT).show()
            stopSelf()
            return
        }
        initTts()
        showBubble()
    }

    private fun initTts() {
        runCatching {
            tts = TextToSpeech(this) { status ->
                ttsReady = (status == TextToSpeech.SUCCESS)
            }
        }
    }

    private fun speakText(text: String, locale: Locale) {
        if (!ttsReady || text.isBlank()) return
        runCatching {
            tts?.language = locale
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "eh_tts")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SHOW_BUBBLE -> {
                isHiddenToNotification = false
                if (bubbleView == null && Settings.canDrawOverlays(this)) {
                    showBubble()
                }
                bubbleView?.visibility = View.VISIBLE
            }
            ACTION_SET_PROJECTION -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA_INTENT)
                }
                if (resultCode == Activity.RESULT_OK && data != null) {
                    if (!startForegroundCompat(withMediaProjection = true)) {
                        Toast.makeText(this, "Screen OCR permission unavailable", Toast.LENGTH_SHORT).show()
                        return START_NOT_STICKY
                    }
                    runCatching {
                        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        mediaProjection?.stop()
                        mediaProjection = mgr.getMediaProjection(resultCode, data)?.apply {
                            registerCallback(object : MediaProjection.Callback() {
                                override fun onStop() {
                                    mediaProjection = null
                                }
                            }, mainHandler)
                        }
                    }.onFailure {
                        Toast.makeText(this, "Could not start screen capture", Toast.LENGTH_SHORT).show()
                        return START_NOT_STICKY
                    }
                    runScreenOcrCapture()
                } else {
                    Toast.makeText(this, "Screen capture permission cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        runCatching { mediaProjection?.stop() }
        runCatching { tts?.stop(); tts?.shutdown() }
        translatorEngine.close()
        screenCaptureManager.close()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        popupView?.let { runCatching { windowManager.removeView(it) } }
        screenOverlayView?.let { runCatching { windowManager.removeView(it) } }
    }

    private fun startForegroundCompat(withMediaProjection: Boolean): Boolean {
        val notification = buildNotification()
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val type = if (withMediaProjection) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                }
                startForeground(NOTIFICATION_ID, notification, type)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && withMediaProjection) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        }.getOrElse {
            false
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Translator Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_SHOW_BUBBLE },
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bubble_translate)
            .setContentTitle("Easy Hinglish Screen Translator")
            .setContentText("Tap floating bubble once to translate screen in Roman Hindi")
            .setContentIntent(openIntent)
            .addAction(0, "Show Bubble", showIntent)
            .addAction(0, "Close", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun showBubble() {
        if (bubbleView != null || !Settings.canDrawOverlays(this)) return
        val view = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_bubble, null)
        }.getOrNull() ?: return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 300
        }

        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            toggleManualPopup()
        }

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    longPressed = false
                    mainHandler.postDelayed(longPressRunnable, 550L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        moved = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    params.x = initX + dx
                    params.y = initY + dy
                    runCatching { windowManager.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (!moved && !longPressed) {
                        triggerInstantScreenTranslate()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    true
                }
                else -> false
            }
        }

        runCatching {
            windowManager.addView(view, params)
            bubbleView = view
            bubbleParams = params
        }.onFailure {
            Toast.makeText(this, "Could not show floating bubble", Toast.LENGTH_SHORT).show()
        }
    }

    private fun triggerInstantScreenTranslate() {
        if (screenOverlayView != null) {
            closeScreenOverlay()
            return
        }
        if (popupView != null) {
            closeManualPopup()
        }
        if (mediaProjection == null) {
            requestScreenCapturePermission()
        } else {
            runScreenOcrCapture()
        }
    }

    private fun requestScreenCapturePermission() {
        runCatching {
            val permIntent = Intent(this, MediaProjectionPermissionActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(permIntent)
        }.onFailure {
            Toast.makeText(this, "Could not request screen capture permission", Toast.LENGTH_SHORT).show()
        }
    }

    private fun runScreenOcrCapture() {
        val projection = mediaProjection
        if (projection == null) {
            requestScreenCapturePermission()
            return
        }
        if (isCapturing) return
        isCapturing = true

        scope.launch {
            try {
                closeManualPopup()
                closeScreenOverlay()
                bubbleView?.visibility = View.GONE
                delay(220)

                val captureResult = try {
                    withContext(Dispatchers.IO) {
                        screenCaptureManager.captureScreenBlocks(projection)
                    }
                } catch (sec: SecurityException) {
                    mediaProjection = null
                    null
                } catch (ill: IllegalStateException) {
                    if (ill.message?.contains("projection", ignoreCase = true) == true) {
                        mediaProjection = null
                    }
                    null
                } catch (ex: Exception) {
                    null
                }

                if (!isHiddenToNotification) {
                    bubbleView?.visibility = View.VISIBLE
                }

                if (captureResult == null) {
                    if (mediaProjection == null) {
                        requestScreenCapturePermission()
                    } else {
                        Toast.makeText(this@FloatingBubbleService, "Could not read screen. Tap bubble again.", Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }

                if (captureResult.blocks.isEmpty()) {
                    Toast.makeText(this@FloatingBubbleService, "No English text found on screen", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                Toast.makeText(this@FloatingBubbleService, "Translating to ${currentMode.label}...", Toast.LENGTH_SHORT).show()

                val translatedBlocks = try {
                    withContext(Dispatchers.IO) {
                        translatorEngine.translateBlocks(captureResult.blocks, currentMode, dictionaryStore.getEntries())
                    }
                } catch (ex: Exception) {
                    Toast.makeText(
                        this@FloatingBubbleService,
                        "First-time translation needs internet once to download offline Hindi pack.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                if (translatedBlocks.isEmpty()) {
                    Toast.makeText(this@FloatingBubbleService, "No translatable English text found", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                showScreenTranslationOverlay(captureResult, translatedBlocks)
            } finally {
                isCapturing = false
            }
        }
    }

    private fun showScreenTranslationOverlay(
        capture: ScreenOcrCapture,
        initialBlocks: List<TranslatedOverlayBlock>
    ) {
        if (!Settings.canDrawOverlays(this)) return
        closeScreenOverlay()

        val root = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_screen_translations, null)
        }.getOrElse {
            Toast.makeText(this, "Could not open screen overlay", Toast.LENGTH_SHORT).show()
            return
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val boxesContainer = root.findViewById<FrameLayout>(R.id.boxesContainer)
        val bottomHintBar = root.findViewById<LinearLayout>(R.id.bottomHintBar)
        val detailSheet = root.findViewById<LinearLayout>(R.id.detailSheet)
        val tvDetailSource = root.findViewById<TextView>(R.id.tvDetailSource)
        val tvDetailModeLabel = root.findViewById<TextView>(R.id.tvDetailModeLabel)
        val tvDetailTranslated = root.findViewById<TextView>(R.id.tvDetailTranslated)
        val btnDetailSpeakEn = root.findViewById<Button>(R.id.btnDetailSpeakEn)
        val btnDetailSpeakHi = root.findViewById<Button>(R.id.btnDetailSpeakHi)
        val btnDetailCopy = root.findViewById<Button>(R.id.btnDetailCopy)
        val btnDetailClose = root.findViewById<ImageButton>(R.id.btnDetailClose)

        val btnRoman = root.findViewById<Button>(R.id.btnOverlayRoman)
        val btnHinglish = root.findViewById<Button>(R.id.btnOverlayHinglish)
        val btnHindi = root.findViewById<Button>(R.id.btnOverlayHindi)
        val btnRescan = root.findViewById<ImageButton>(R.id.btnOverlayRescan)
        val btnClose = root.findViewById<ImageButton>(R.id.btnOverlayClose)

        bottomHintBar.background = GradientDrawable().apply {
            setColor(0xEE0F172A.toInt())
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), 0xFF334155.toInt())
        }
        detailSheet.background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), 0xFFE2E8F0.toInt())
        }

        var currentBlocks = initialBlocks
        var selectedBlockIndex = -1

        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels.coerceAtLeast(320)
        val screenH = metrics.heightPixels.coerceAtLeast(320)
        val scaleX = screenW.toFloat() / capture.bitmapWidth.coerceAtLeast(1).toFloat()
        val scaleY = screenH.toFloat() / capture.bitmapHeight.coerceAtLeast(1).toFloat()

        fun styleModeBtn(btn: Button, active: Boolean) {
            btn.background = GradientDrawable().apply {
                setColor(if (active) 0xFF2563EB.toInt() else 0xFF1E293B.toInt())
                cornerRadius = dp(10).toFloat()
            }
            btn.setTextColor(if (active) Color.WHITE else 0xFFCBD5E1.toInt())
        }

        fun refreshModeButtons() {
            styleModeBtn(btnRoman, currentMode == TranslationMode.ROMAN_HINDI)
            styleModeBtn(btnHinglish, currentMode == TranslationMode.HINGLISH)
            styleModeBtn(btnHindi, currentMode == TranslationMode.EASY_HINDI)
        }

        fun updateDetailCard(idx: Int) {
            if (idx !in currentBlocks.indices) {
                detailSheet.visibility = View.GONE
                bottomHintBar.visibility = View.VISIBLE
                return
            }
            val block = currentBlocks[idx]
            tvDetailSource.text = block.sourceText
            tvDetailModeLabel.text = currentMode.label
            tvDetailTranslated.text = block.translatedText
            detailSheet.visibility = View.VISIBLE
            bottomHintBar.visibility = View.GONE
        }

        fun renderBoxes() {
            boxesContainer.removeAllViews()
            val padH = dp(7)
            val padV = dp(4)

            currentBlocks.forEachIndexed { index, block ->
                val scaledLeft = (block.left * scaleX).toInt().coerceIn(dp(4), screenW - dp(80))
                val scaledTop = (block.top * scaleY).toInt().coerceIn(dp(8), screenH - dp(90))
                val scaledRight = (block.right * scaleX).toInt().coerceAtLeast(scaledLeft + dp(70))
                val boxWidth = (scaledRight - scaledLeft + dp(12)).coerceIn(dp(90), screenW - scaledLeft - dp(6))
                val boxHeight = ((block.bottom - block.top) * scaleY).toInt()

                val tv = TextView(themedContext).apply {
                    text = block.translatedText
                    setTextColor(Color.WHITE)
                    val fontSp = when {
                        boxHeight < dp(28) -> 11f
                        boxHeight < dp(64) -> 12.5f
                        else -> 13.5f
                    }
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp)
                    setPadding(padH, padV, padH, padV)
                    background = GradientDrawable().apply {
                        setColor(if (index == selectedBlockIndex) 0xF51E3A8A.toInt() else 0xEB0F172A.toInt())
                        cornerRadius = dp(8).toFloat()
                        setStroke(dp(1), if (index == selectedBlockIndex) 0xFF60A5FA.toInt() else 0xFF475569.toInt())
                    }
                    setOnClickListener {
                        selectedBlockIndex = index
                        renderBoxes()
                        updateDetailCard(index)
                    }
                }

                val lp = FrameLayout.LayoutParams(boxWidth, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
                    leftMargin = scaledLeft
                    topMargin = scaledTop
                }
                boxesContainer.addView(tv, lp)
            }
        }

        fun switchMode(newMode: TranslationMode) {
            currentMode = newMode
            dictionaryStore.setDefaultMode(newMode)
            val dict = dictionaryStore.getEntries()
            currentBlocks = currentBlocks.map { blk ->
                val (formatted, _) = translatorEngine.formatHindiForMode(blk.rawHindiText, newMode, dict)
                blk.copy(translatedText = formatted)
            }
            refreshModeButtons()
            renderBoxes()
            if (selectedBlockIndex in currentBlocks.indices) {
                updateDetailCard(selectedBlockIndex)
            }
        }

        refreshModeButtons()
        renderBoxes()

        btnRoman.setOnClickListener { switchMode(TranslationMode.ROMAN_HINDI) }
        btnHinglish.setOnClickListener { switchMode(TranslationMode.HINGLISH) }
        btnHindi.setOnClickListener { switchMode(TranslationMode.EASY_HINDI) }

        btnRescan.setOnClickListener {
            closeScreenOverlay()
            runScreenOcrCapture()
        }
        btnClose.setOnClickListener {
            closeScreenOverlay()
        }

        btnDetailClose.setOnClickListener {
            selectedBlockIndex = -1
            detailSheet.visibility = View.GONE
            bottomHintBar.visibility = View.VISIBLE
            renderBoxes()
        }
        btnDetailSpeakEn.setOnClickListener {
            speakText(tvDetailSource.text.toString(), Locale.US)
        }
        btnDetailSpeakHi.setOnClickListener {
            val idx = selectedBlockIndex
            val speakStr = if (idx in currentBlocks.indices) currentBlocks[idx].rawHindiText else tvDetailTranslated.text.toString()
            speakText(speakStr, Locale("hi", "IN"))
        }
        btnDetailCopy.setOnClickListener {
            val out = tvDetailTranslated.text.toString()
            if (out.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("EasyHinglish", out))
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
            }
        }

        // Swipe up or tap dim background to dismiss overlay
        var downY = 0f
        var downX = 0f
        root.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dy = ev.rawY - downY
                    val dx = ev.rawX - downX
                    if (dy < -dp(60)) {
                        closeScreenOverlay()
                    } else if (abs(dx) < dp(12) && abs(dy) < dp(12)) {
                        if (detailSheet.visibility == View.VISIBLE) {
                            selectedBlockIndex = -1
                            detailSheet.visibility = View.GONE
                            bottomHintBar.visibility = View.VISIBLE
                            renderBoxes()
                        } else {
                            closeScreenOverlay()
                        }
                    }
                    true
                }
                else -> false
            }
        }

        runCatching {
            bubbleView?.visibility = View.GONE
            windowManager.addView(root, params)
            screenOverlayView = root
        }.onFailure {
            if (!isHiddenToNotification) bubbleView?.visibility = View.VISIBLE
            Toast.makeText(this, "Could not show translation overlay", Toast.LENGTH_SHORT).show()
        }
    }

    private fun closeScreenOverlay() {
        runCatching { tts?.stop() }
        screenOverlayView?.let { runCatching { windowManager.removeView(it) } }
        screenOverlayView = null
        if (!isHiddenToNotification) {
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun toggleManualPopup() {
        if (popupView != null) {
            closeManualPopup()
            return
        }
        if (!Settings.canDrawOverlays(this)) return

        val view = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_popup, null)
        }.getOrElse {
            Toast.makeText(this, "Could not open translator popup", Toast.LENGTH_SHORT).show()
            return
        }

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90).toInt().coerceAtLeast(300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val btnEasy = view.findViewById<Button>(R.id.btnModeEasy)
        val btnRoman = view.findViewById<Button>(R.id.btnModeRoman)
        val btnHinglish = view.findViewById<Button>(R.id.btnModeHinglish)
        val btnOcr = view.findViewById<Button>(R.id.btnPopupOcr)
        val btnPaste = view.findViewById<Button>(R.id.btnPopupPaste)
        val btnCopy = view.findViewById<Button>(R.id.btnPopupCopy)
        val btnClear = view.findViewById<Button>(R.id.btnPopupClear)
        val btnAgain = view.findViewById<Button>(R.id.btnPopupAgain)
        val btnHide = view.findViewById<ImageButton>(R.id.btnPopupHide)
        val btnClose = view.findViewById<ImageButton>(R.id.btnPopupClose)
        val inputEdit = view.findViewById<EditText>(R.id.etPopupInput)
        val outputText = view.findViewById<TextView>(R.id.tvPopupOutput)

        inputEdit.setText(lastEnglishText)

        fun styleModeBtn(btn: Button, active: Boolean) {
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (active) 0xFF2563EB.toInt() else 0xFFE2E8F0.toInt()
            )
            btn.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF0F172A.toInt())
        }

        fun refreshModeButtons() {
            styleModeBtn(btnEasy, currentMode == TranslationMode.EASY_HINDI)
            styleModeBtn(btnRoman, currentMode == TranslationMode.ROMAN_HINDI)
            styleModeBtn(btnHinglish, currentMode == TranslationMode.HINGLISH)
        }
        refreshModeButtons()

        fun translateNow(source: String) {
            val clean = source.trim()
            if (clean.isEmpty()) return
            lastEnglishText = clean
            outputText.text = "Translating..."
            scope.launch {
                try {
                    val res = withContext(Dispatchers.IO) {
                        translatorEngine.translate(clean, currentMode, dictionaryStore.getEntries())
                    }
                    outputText.text = res.translatedText
                } catch (ex: Exception) {
                    outputText.text = "First-time translation needs internet once to download free offline Hindi pack."
                }
            }
        }

        btnEasy.setOnClickListener {
            currentMode = TranslationMode.EASY_HINDI
            dictionaryStore.setDefaultMode(currentMode)
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }
        btnRoman.setOnClickListener {
            currentMode = TranslationMode.ROMAN_HINDI
            dictionaryStore.setDefaultMode(currentMode)
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }
        btnHinglish.setOnClickListener {
            currentMode = TranslationMode.HINGLISH
            dictionaryStore.setDefaultMode(currentMode)
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }

        btnOcr.setOnClickListener {
            closeManualPopup()
            triggerInstantScreenTranslate()
        }

        btnPaste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val primary = cm.primaryClip
            val clipText = if (primary != null && primary.itemCount > 0) {
                primary.getItemAt(0).coerceToText(this)?.toString().orEmpty()
            } else {
                ""
            }
            if (clipText.isNotBlank()) {
                inputEdit.setText(clipText)
                translateNow(clipText)
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }

        btnCopy.setOnClickListener {
            val translated = outputText.text.toString()
            if (translated.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("EasyHinglish", translated))
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
            }
        }

        btnClear.setOnClickListener {
            lastEnglishText = ""
            inputEdit.setText("")
            outputText.text = ""
        }

        btnAgain.setOnClickListener {
            translateNow(inputEdit.text.toString())
        }

        btnHide.setOnClickListener {
            closeManualPopup()
            isHiddenToNotification = true
            bubbleView?.visibility = View.GONE
            Toast.makeText(this, "Bubble hidden. Tap notification to show again.", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener {
            stopSelf()
        }

        runCatching {
            windowManager.addView(view, params)
            popupView = view
            popupParams = params
        }.onFailure {
            Toast.makeText(this, "Could not open floating popup", Toast.LENGTH_SHORT).show()
        }
    }

    private fun closeManualPopup() {
        popupView?.let { runCatching { windowManager.removeView(it) } }
        popupView = null
        popupParams = null
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    companion object {
        const val CHANNEL_ID = "easy_hinglish_overlay_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.easyhinglish.translator.STOP"
        const val ACTION_SHOW_BUBBLE = "com.easyhinglish.translator.SHOW_BUBBLE"
        const val ACTION_SET_PROJECTION = "com.easyhinglish.translator.SET_PROJECTION"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"
    }
}
