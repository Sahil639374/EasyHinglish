package com.easyhinglish.translator.service

import android.app.Activity
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.easyhinglish.translator.R
import com.easyhinglish.translator.data.DictionaryStore
import com.easyhinglish.translator.model.ScreenOcrCapture
import com.easyhinglish.translator.model.TranslatedOverlayBlock
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.ocr.ScreenCaptureManager
import com.easyhinglish.translator.translation.TranslatorEngine
import com.easyhinglish.translator.ui.MainActivity
import com.easyhinglish.translator.ui.MediaProjectionPermissionActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.math.abs

class FloatingBubbleService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private lateinit var dictionaryStore: DictionaryStore
    private lateinit var translatorEngine: TranslatorEngine
    private lateinit var screenCaptureManager: ScreenCaptureManager
    private val themedContext by lazy { ContextThemeWrapper(this, R.style.Theme_EasyHinglish) }

    private var bubbleView: View? = null
    private var popupView: View? = null
    private var screenOverlayView: View? = null
    private var translationPopupView: View? = null

    private var bubbleParams: WindowManager.LayoutParams? = null
    private var popupParams: WindowManager.LayoutParams? = null
    private var translationPopupParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var currentMode: TranslationMode = TranslationMode.ROMAN_HINDI
    private var lastEnglishText: String = ""
    private var isHiddenToNotification = false
    private var isCapturing = false

    private var currentOverlayBlocks: List<TranslatedOverlayBlock> = emptyList()
    private var selectedOverlayIndex: Int = -1
    private var refreshOverlayCallback: (() -> Unit)? = null

    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false
    private var pendingSpeech: Triple<String, Locale, String>? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        dictionaryStore = DictionaryStore(this)
        translatorEngine = TranslatorEngine()
        screenCaptureManager = ScreenCaptureManager(this)
        currentMode = dictionaryStore.getDefaultMode()

        createNotificationChannel()
        if (!startForegroundCompat(withMediaProjection = false)) {
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' first", Toast.LENGTH_SHORT).show()
            stopSelf()
            return
        }
        initTts()
        isRunning = true
        showBubble()
        scope.launch(Dispatchers.IO) {
            runCatching { translatorEngine.ensureModelReady() }
        }
    }

    private fun initTts() {
        runCatching { tts?.shutdown() }
        ttsReady = false
        runCatching {
            tts = TextToSpeech(this) { status ->
                val ready = (status == TextToSpeech.SUCCESS)
                mainHandler.post {
                    ttsReady = ready
                    if (ready) {
                        val queued = pendingSpeech
                        pendingSpeech = null
                        if (queued != null) {
                            speakText(queued.first, queued.second, queued.third)
                        }
                    }
                }
            }
        }
    }

    private fun splitSpeechChunks(input: String, maxChunkLen: Int = 1200): List<String> {
        val clean = input.replace(Regex("\\s+"), " ").trim()
        if (clean.length <= maxChunkLen) return listOf(clean)
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < clean.length) {
            val hardEnd = minOf(start + maxChunkLen, clean.length)
            if (hardEnd == clean.length) {
                chunks.add(clean.substring(start).trim())
                break
            }
            var splitAt = -1
            for (i in hardEnd downTo start + (maxChunkLen / 2)) {
                val ch = clean[i - 1]
                if (ch == '.' || ch == '।' || ch == '?' || ch == '!' || ch == '\n' || ch == ',') {
                    splitAt = i
                    break
                }
            }
            if (splitAt <= start) {
                splitAt = clean.lastIndexOf(' ', hardEnd).let { if (it > start) it else hardEnd }
            }
            val piece = clean.substring(start, splitAt).trim()
            if (piece.isNotEmpty()) chunks.add(piece)
            start = splitAt
            while (start < clean.length && clean[start].isWhitespace()) start++
        }
        return chunks.ifEmpty { listOf(clean) }
    }

    private fun speakText(text: String, locale: Locale, fallbackText: String = text) {
        if (text.isBlank()) return
        if (!ttsReady || tts == null) {
            pendingSpeech = Triple(text, locale, fallbackText)
            initTts()
            Toast.makeText(this, "Voice starting...", Toast.LENGTH_SHORT).show()
            return
        }
        val success = runCatching {
            val engine = tts ?: return@runCatching false
            val langResult = engine.setLanguage(locale)
            val chosenText = if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                val fallbackLang = engine.setLanguage(Locale.getDefault())
                if (fallbackLang == TextToSpeech.LANG_MISSING_DATA || fallbackLang == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.setLanguage(Locale.US)
                }
                fallbackText
            } else {
                text
            }
            val chunks = splitSpeechChunks(chosenText)
            var allOk = true
            chunks.forEachIndexed { index, chunk ->
                val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val code = engine.speak(chunk, queueMode, null, "eh_tts_$index")
                if (code == TextToSpeech.ERROR) {
                    allOk = false
                }
            }
            allOk
        }.getOrDefault(false)

        if (!success) {
            pendingSpeech = Triple(text, locale, fallbackText)
            initTts()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_VOICE -> {
                pendingSpeech = null
                runCatching { tts?.stop() }
                Toast.makeText(this, "Voice stopped", Toast.LENGTH_SHORT).show()
            }
            ACTION_SHOW_BUBBLE -> {
                isHiddenToNotification = false
                if (bubbleView == null && Settings.canDrawOverlays(this)) {
                    showBubble()
                }
                bubbleView?.visibility = View.VISIBLE
            }
            ACTION_OPEN_MANUAL_POPUP -> {
                isHiddenToNotification = false
                if (bubbleView == null && Settings.canDrawOverlays(this)) {
                    showBubble()
                }
                bubbleView?.visibility = View.VISIBLE
                if (popupView == null) {
                    toggleManualPopup()
                }
            }
            ACTION_SET_PROJECTION -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA_INTENT)
                }
                if (resultCode == Activity.RESULT_OK && data != null) {
                    if (!startForegroundCompat(withMediaProjection = true)) {
                        Toast.makeText(this, "Screen OCR permission unavailable", Toast.LENGTH_SHORT).show()
                        return START_NOT_STICKY
                    }
                    runCatching {
                        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        screenCaptureManager.releasePersistentSurface()
                        mediaProjection?.stop()
                        mediaProjection = mgr.getMediaProjection(resultCode, data)?.apply {
                            registerCallback(object : MediaProjection.Callback() {
                                override fun onStop() {
                                    screenCaptureManager.releasePersistentSurface()
                                    mediaProjection = null
                                }
                            }, mainHandler)
                        }
                    }.onFailure {
                        Toast.makeText(this, "Could not start screen capture", Toast.LENGTH_SHORT).show()
                        return START_NOT_STICKY
                    }
                    scope.launch {
                        delay(150L)
                        runScreenOcrCapture()
                    }
                } else {
                    Toast.makeText(this, "Screen capture permission cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val view = translationPopupView
        val params = translationPopupParams
        if (view != null && params != null) {
            val metrics = resources.displayMetrics
            val screenW = metrics.widthPixels.coerceAtLeast(320)
            params.width = minOf((screenW * 0.94).toInt(), dp(540)).coerceAtLeast(dp(280))
            runCatching { windowManager.updateViewLayout(view, params) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        scope.cancel()
        runCatching { mediaProjection?.stop() }
        runCatching { tts?.stop(); tts?.shutdown() }
        translatorEngine.close()
        screenCaptureManager.close()
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        popupView?.let { runCatching { windowManager.removeView(it) } }
        screenOverlayView?.let { runCatching { windowManager.removeView(it) } }
        translationPopupView?.let { runCatching { windowManager.removeView(it) } }
    }

    private fun startForegroundCompat(withMediaProjection: Boolean): Boolean {
        val notification = buildNotification()
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val type = if (withMediaProjection) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                }
                startForeground(NOTIFICATION_ID, notification, type)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && withMediaProjection) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        }.getOrElse {
            false
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Translator Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_SHOW_BUBBLE },
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopVoiceIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP_VOICE },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bubble_translate)
            .setContentTitle("Easy Hinglish Screen Translator")
            .setContentText("Tap bubble once to translate all screen text to Roman Hindi")
            .setContentIntent(openIntent)
            .addAction(0, "Show Bubble", showIntent)
            .addAction(0, "Stop Voice", stopVoiceIntent)
            .addAction(0, "Close", stopIntent)
            .setOngoing(true)
            .build()
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun showBubble() {
        if (bubbleView != null || !Settings.canDrawOverlays(this)) return
        val view = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_bubble, null)
        }.getOrNull() ?: return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 300
        }

        val touchSlop = maxOf(ViewConfiguration.get(this).scaledTouchSlop, dp(14))
        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var longPressed = false
        val longPressRunnable = Runnable {
            longPressed = true
            toggleManualPopup()
        }

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    longPressed = false
                    view.scaleX = 0.90f
                    view.scaleY = 0.90f
                    view.alpha = 0.78f
                    mainHandler.postDelayed(longPressRunnable, 750L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        moved = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    if (moved) {
                        params.x = initX + dx
                        params.y = initY + dy
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    view.scaleX = 1.0f
                    view.scaleY = 1.0f
                    view.alpha = 1.0f
                    if (!moved && !longPressed) {
                        triggerInstantScreenTranslate()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    view.scaleX = 1.0f
                    view.scaleY = 1.0f
                    view.alpha = 1.0f
                    true
                }
                else -> false
            }
        }

        runCatching {
            windowManager.addView(view, params)
            bubbleView = view
            bubbleParams = params
        }.onFailure {
            Toast.makeText(this, "Could not show floating bubble", Toast.LENGTH_SHORT).show()
        }
    }

    private fun triggerInstantScreenTranslate() {
        if (screenOverlayView != null) {
            closeAllTranslationOverlays()
            return
        }
        if (popupView != null) {
            closeManualPopup()
        }
        if (EasyHinglishAccessibilityService.isReady() || mediaProjection != null) {
            runScreenOcrCapture()
        } else {
            Toast.makeText(
                this,
                "Allow Screen Capture or enable Accessibility 1-Tap Scan in app",
                Toast.LENGTH_SHORT
            ).show()
            requestScreenCapturePermission()
        }
    }

    private fun requestScreenCapturePermission() {
        runCatching {
            val permIntent = Intent(this, MediaProjectionPermissionActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    101,
                    permIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val opts = ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                pendingIntent.send(this, 0, null, null, null, null, opts.toBundle())
            } else {
                startActivity(permIntent)
            }
        }.onFailure {
            Toast.makeText(
                this,
                "Open Easy Hinglish app & enable Accessibility 1-Tap Scan for instant capture",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun runScreenOcrCapture() {
        val accessibilityService = EasyHinglishAccessibilityService.instance
        val projection = mediaProjection
        if (accessibilityService == null && projection == null) {
            requestScreenCapturePermission()
            return
        }
        if (isCapturing) return
        isCapturing = true

        scope.launch {
            try {
                closeManualPopup()
                closeAllTranslationOverlays()
                bubbleView?.visibility = View.GONE
                delay(65)

                var captureResult: ScreenOcrCapture? = null

                // Engine 1 (Primary): Zero-prompt Accessibility Screenshot (Android 11-16)
                if (accessibilityService != null) {
                    val bmp = withTimeoutOrNull(4500L) {
                        accessibilityService.captureScreenBitmapWithRetry()
                    }
                    if (!isHiddenToNotification) {
                        bubbleView?.visibility = View.VISIBLE
                    }
                    if (bmp != null) {
                        captureResult = runCatching {
                            withContext(Dispatchers.IO) {
                                screenCaptureManager.recognizeBlocksFromBitmap(bmp)
                            }
                        }.getOrNull()
                    }
                    if (captureResult == null || captureResult.blocks.isEmpty()) {
                        val treeCapture = accessibilityService.captureVisibleTextBlocks()
                        if (treeCapture != null && treeCapture.blocks.isNotEmpty()) {
                            captureResult = treeCapture
                        }
                    }
                }

                // Engine 2 (Fallback): Repaired Persistent MediaProjection
                if ((captureResult == null || captureResult.blocks.isEmpty()) && projection != null) {
                    if (accessibilityService != null) {
                        bubbleView?.visibility = View.GONE
                        delay(80)
                    }
                    captureResult = try {
                        withTimeoutOrNull(5000L) {
                            withContext(Dispatchers.IO) {
                                screenCaptureManager.captureScreenBlocks(projection)
                            }
                        }
                    } catch (_: SecurityException) {
                        screenCaptureManager.releasePersistentSurface()
                        mediaProjection = null
                        null
                    } catch (ill: IllegalStateException) {
                        if (ill.message?.contains("projection", ignoreCase = true) == true) {
                            screenCaptureManager.releasePersistentSurface()
                            mediaProjection = null
                        }
                        null
                    } catch (_: Exception) {
                        null
                    }
                }

                if (!isHiddenToNotification && screenOverlayView == null) {
                    bubbleView?.visibility = View.VISIBLE
                }

                if (captureResult == null) {
                    if (EasyHinglishAccessibilityService.isReady()) {
                        Toast.makeText(this@FloatingBubbleService, "No text captured. Tap bubble again.", Toast.LENGTH_SHORT).show()
                    } else if (mediaProjection == null) {
                        requestScreenCapturePermission()
                    } else {
                        Toast.makeText(this@FloatingBubbleService, "Could not read screen. Enable Accessibility in app or tap again.", Toast.LENGTH_LONG).show()
                    }
                    return@launch
                }

                val detectedBlocks = captureResult.blocks.filter { it.text.isNotBlank() }
                if (detectedBlocks.isEmpty()) {
                    Toast.makeText(this@FloatingBubbleService, "No English text found on screen", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val entries = dictionaryStore.getEntries()
                val sortedRawBlocks = detectedBlocks.sortedWith(
                    compareBy<com.easyhinglish.translator.model.OcrTextBlock>({ it.top / 42 }, { it.left })
                )

                if (dictionaryStore.isShowScreenBoxesEnabled()) {
                    val translatedBlocks = try {
                        withTimeoutOrNull(25_000L) {
                            withContext(Dispatchers.IO) {
                                translatorEngine.translateBlocks(sortedRawBlocks, currentMode, entries)
                            }
                        } ?: throw IllegalStateException("Translation timed out")
                    } catch (ex: Exception) {
                        Toast.makeText(
                            this@FloatingBubbleService,
                            "Translation error: ${ex.localizedMessage ?: "Try again"}",
                            Toast.LENGTH_LONG
                        ).show()
                        return@launch
                    }

                    if (translatedBlocks.isEmpty()) {
                        Toast.makeText(this@FloatingBubbleService, "No translatable English text found", Toast.LENGTH_SHORT).show()
                        return@launch
                    }
                    showScreenTranslationOverlay(captureResult, translatedBlocks)
                } else {
                    val allEnglish = sortedRawBlocks.joinToString("\n") { it.text.replace(Regex("\\s+"), " ").trim() }
                    val (rawHindi, translatedRes) = try {
                        withTimeoutOrNull(20_000L) {
                            withContext(Dispatchers.IO) {
                                translatorEngine.translateWithRaw(allEnglish, currentMode, entries)
                            }
                        } ?: throw IllegalStateException("Translation timed out")
                    } catch (ex: Exception) {
                        Toast.makeText(
                            this@FloatingBubbleService,
                            "Translation error: ${ex.localizedMessage ?: "Try again"}",
                            Toast.LENGTH_LONG
                        ).show()
                        return@launch
                    }

                    if (translatedRes.translatedText.isBlank()) {
                        Toast.makeText(this@FloatingBubbleService, "No translatable English text found", Toast.LENGTH_SHORT).show()
                        return@launch
                    }
                    lastEnglishText = allEnglish
                    showTranslationPopup(allEnglish, rawHindi, translatedRes.translatedText)
                }
            } finally {
                isCapturing = false
                if (!isHiddenToNotification && screenOverlayView == null) {
                    bubbleView?.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showScreenTranslationOverlay(
        capture: ScreenOcrCapture,
        initialBlocks: List<TranslatedOverlayBlock>
    ) {
        if (!Settings.canDrawOverlays(this)) return
        closeAllTranslationOverlays()

        val root = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_screen_translations, null)
        }.getOrElse {
            Toast.makeText(this, "Could not open screen overlay", Toast.LENGTH_SHORT).show()
            return
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val boxesContainer = root.findViewById<FrameLayout>(R.id.boxesContainer)
        val bottomHintBar = root.findViewById<LinearLayout>(R.id.bottomHintBar)
        val btnRoman = root.findViewById<Button>(R.id.btnOverlayRoman)
        val btnHinglish = root.findViewById<Button>(R.id.btnOverlayHinglish)
        val btnHindi = root.findViewById<Button>(R.id.btnOverlayHindi)
        val btnRescan = root.findViewById<ImageButton>(R.id.btnOverlayRescan)
        val btnClose = root.findViewById<ImageButton>(R.id.btnOverlayClose)

        bottomHintBar.background = GradientDrawable().apply {
            setColor(0xEE0F172A.toInt())
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), 0xFF334155.toInt())
        }

        currentOverlayBlocks = initialBlocks
        // Auto-select the first meaningful paragraph/sentence for the bottom card
        selectedOverlayIndex = initialBlocks.indexOfFirst { it.sourceText.length >= 16 }
            .let { if (it >= 0) it else 0 }

        val (screenW, screenH) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = windowManager.currentWindowMetrics.bounds
            b.width().coerceAtLeast(320) to b.height().coerceAtLeast(320)
        } else {
            val pt = android.graphics.Point()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay?.getRealSize(pt)
            if (pt.x > 0 && pt.y > 0) {
                pt.x to pt.y
            } else {
                val m = resources.displayMetrics
                m.widthPixels.coerceAtLeast(320) to m.heightPixels.coerceAtLeast(320)
            }
        }
        val scaleX = screenW.toFloat() / capture.bitmapWidth.coerceAtLeast(1).toFloat()
        val scaleY = screenH.toFloat() / capture.bitmapHeight.coerceAtLeast(1).toFloat()

        fun styleModeBtn(btn: Button, active: Boolean) {
            btn.background = GradientDrawable().apply {
                setColor(if (active) 0xFF2563EB.toInt() else 0xFF1E293B.toInt())
                cornerRadius = dp(12).toFloat()
            }
            btn.setTextColor(if (active) Color.WHITE else 0xFFCBD5E1.toInt())
        }

        fun refreshModeButtons() {
            styleModeBtn(btnRoman, currentMode == TranslationMode.ROMAN_HINDI)
            styleModeBtn(btnHinglish, currentMode == TranslationMode.HINGLISH)
            styleModeBtn(btnHindi, currentMode == TranslationMode.EASY_HINDI)
        }

        fun renderBoxes() {
            boxesContainer.removeAllViews()
            val padH = dp(8)
            val padV = dp(4)
            val placedRects = mutableListOf<android.graphics.Rect>()
            val maxBottom = (screenH - dp(86)).coerceAtLeast(dp(200))

            currentOverlayBlocks.forEachIndexed { index, block ->
                val scaledLeft = (block.left * scaleX).toInt().coerceIn(dp(4), screenW - dp(80))
                val scaledTop = (block.top * scaleY).toInt().coerceIn(dp(8), screenH - dp(80))
                val scaledRight = (block.right * scaleX).toInt().coerceAtLeast(scaledLeft + dp(70))
                val boxWidth = (scaledRight - scaledLeft + dp(14)).coerceIn(dp(96), screenW - scaledLeft - dp(6))
                val boxHeight = ((block.bottom - block.top) * scaleY).toInt()
                val isSelected = index == selectedOverlayIndex && translationPopupView != null

                val tv = TextView(themedContext).apply {
                    text = block.translatedText
                    setTextColor(Color.WHITE)
                    val fontSp = when {
                        boxHeight < dp(28) -> 11.5f
                        boxHeight < dp(64) -> 13f
                        else -> 13.5f
                    }
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp)
                    setPadding(padH, padV, padH, padV)
                    background = GradientDrawable().apply {
                        setColor(if (isSelected) 0xF51E3A8A.toInt() else 0xEB0F172A.toInt())
                        cornerRadius = dp(8).toFloat()
                        setStroke(dp(1), if (isSelected) 0xFF60A5FA.toInt() else 0xFF64748B.toInt())
                    }
                    setOnClickListener {
                        selectedOverlayIndex = index
                        openBottomPopupForBlock(index)
                        renderBoxes()
                    }
                }

                tv.measure(
                    View.MeasureSpec.makeMeasureSpec(boxWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                val measuredH = tv.measuredHeight.coerceAtLeast(dp(24))
                val boxRight = scaledLeft + boxWidth
                var safeTop = scaledTop
                for (prev in placedRects) {
                    val horizOverlap = prev.right > scaledLeft + dp(4) && prev.left < boxRight - dp(4)
                    if (horizOverlap && safeTop < prev.bottom + dp(4)) {
                        safeTop = prev.bottom + dp(4)
                    }
                }
                safeTop = safeTop.coerceAtMost((maxBottom - dp(28)).coerceAtLeast(dp(8)))
                placedRects.add(android.graphics.Rect(scaledLeft, safeTop, boxRight, safeTop + measuredH))

                val lp = FrameLayout.LayoutParams(boxWidth, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
                    leftMargin = scaledLeft
                    topMargin = safeTop
                }
                boxesContainer.addView(tv, lp)
            }
        }

        refreshOverlayCallback = {
            refreshModeButtons()
            renderBoxes()
        }

        fun switchMode(newMode: TranslationMode) {
            currentMode = newMode
            dictionaryStore.setDefaultMode(newMode)
            val dict = dictionaryStore.getEntries()
            currentOverlayBlocks = currentOverlayBlocks.map { blk ->
                val (formatted, _) = translatorEngine.formatHindiForMode(blk.rawHindiText, newMode, dict)
                blk.copy(translatedText = formatted)
            }
            refreshModeButtons()
            renderBoxes()
            if (translationPopupView != null && selectedOverlayIndex in currentOverlayBlocks.indices) {
                openBottomPopupForBlock(selectedOverlayIndex)
            }
        }

        refreshModeButtons()
        renderBoxes()

        btnRoman.setOnClickListener { switchMode(TranslationMode.ROMAN_HINDI) }
        btnHinglish.setOnClickListener { switchMode(TranslationMode.HINGLISH) }
        btnHindi.setOnClickListener { switchMode(TranslationMode.EASY_HINDI) }

        btnRescan.setOnClickListener {
            closeAllTranslationOverlays()
            runScreenOcrCapture()
        }
        btnClose.setOnClickListener {
            closeAllTranslationOverlays()
        }

        // Swipe up or tap dim background to dismiss entire screen overlay
        var downY = 0f
        var downX = 0f
        root.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dy = ev.rawY - downY
                    val dx = ev.rawX - downX
                    if (dy < -dp(55) || (abs(dx) < dp(12) && abs(dy) < dp(12))) {
                        closeAllTranslationOverlays()
                    }
                    true
                }
                else -> false
            }
        }

        runCatching {
            bubbleView?.visibility = View.GONE
            windowManager.addView(root, params)
            screenOverlayView = root
            // Automatically open the bottom 2-card English/Hindi popup for the first detected block
            if (selectedOverlayIndex in currentOverlayBlocks.indices) {
                openBottomPopupForBlock(selectedOverlayIndex)
                renderBoxes()
            }
        }.onFailure {
            if (!isHiddenToNotification) bubbleView?.visibility = View.VISIBLE
            Toast.makeText(this, "Could not show translation overlay", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openBottomPopupForBlock(index: Int) {
        val block = currentOverlayBlocks.getOrNull(index) ?: return
        lastEnglishText = block.sourceText
        showTranslationPopup(block.sourceText, block.rawHindiText, block.translatedText)
    }

    private fun showTranslationPopup(
        englishText: String,
        rawHindiText: String,
        translatedHindiText: String
    ) {
        if (englishText.isBlank() || translatedHindiText.isBlank()) return
        if (!Settings.canDrawOverlays(this)) return

        // Prevent duplicate popup windows
        dismissTranslationPopup()

        val root = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_translation_popup, null)
        }.getOrElse {
            Toast.makeText(this, "Could not open translation popup", Toast.LENGTH_SHORT).show()
            return
        }

        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels.coerceAtLeast(320)
        val screenH = metrics.heightPixels.coerceAtLeast(320)
        val popupWidth = minOf((screenW * 0.94).toInt(), dp(540)).coerceAtLeast(dp(280))

        val params = WindowManager.LayoutParams(
            popupWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(14)
        }

        val scrollView = root.findViewById<ScrollView>(R.id.bottomPopupScroll)
        val tvTitle = root.findViewById<TextView>(R.id.tvBottomPopupTitle)
        val btnClose = root.findViewById<ImageButton>(R.id.btnBottomPopupClose)

        val btnCopyEnglish = root.findViewById<ImageButton>(R.id.btnCardCopyEnglish)
        val btnSpeakEnglish = root.findViewById<ImageButton>(R.id.btnCardSpeakEnglish)
        val tvEnglish = root.findViewById<TextView>(R.id.tvCardEnglishText)

        val tvHindiSub = root.findViewById<TextView>(R.id.tvCardHindiSub)
        val btnCopyHindi = root.findViewById<ImageButton>(R.id.btnCardCopyHindi)
        val btnSpeakHindi = root.findViewById<ImageButton>(R.id.btnCardSpeakHindi)
        val tvHindi = root.findViewById<TextView>(R.id.tvCardHindiText)

        tvEnglish.text = englishText
        tvHindi.text = translatedHindiText
        tvTitle.text = "Floating Overlay (${currentMode.label})"
        tvHindiSub.text = currentMode.label

        fun switchPopupMode(mode: TranslationMode) {
            currentMode = mode
            dictionaryStore.setDefaultMode(mode)
            val dict = dictionaryStore.getEntries()
            if (currentOverlayBlocks.isNotEmpty()) {
                currentOverlayBlocks = currentOverlayBlocks.map { blk ->
                    val (formatted, _) = translatorEngine.formatHindiForMode(blk.rawHindiText, mode, dict)
                    blk.copy(translatedText = formatted)
                }
                refreshOverlayCallback?.invoke()
            }
            val (formatted, _) = translatorEngine.formatHindiForMode(rawHindiText, mode, dict)
            tvTitle.text = "Floating Overlay (${mode.label})"
            tvHindiSub.text = mode.label
            tvHindi.text = formatted
        }

        val cycleModeListener = View.OnClickListener {
            val nextMode = when (currentMode) {
                TranslationMode.ROMAN_HINDI -> TranslationMode.HINGLISH
                TranslationMode.HINGLISH -> TranslationMode.EASY_HINDI
                TranslationMode.EASY_HINDI -> TranslationMode.ROMAN_HINDI
            }
            switchPopupMode(nextMode)
        }
        tvHindiSub.setOnClickListener(cycleModeListener)
        tvTitle.setOnClickListener(cycleModeListener)

        btnCopyEnglish.setOnClickListener {
            val content = tvEnglish.text?.toString().orEmpty()
            if (content.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("English", content))
                Toast.makeText(this, "English text copied!", Toast.LENGTH_SHORT).show()
            }
        }

        btnSpeakEnglish.setOnClickListener {
            val content = tvEnglish.text?.toString().orEmpty()
            if (content.isNotBlank()) {
                speakText(content, Locale.US)
            }
        }

        btnCopyHindi.setOnClickListener {
            val content = tvHindi.text?.toString().orEmpty()
            if (content.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Hindi Translation", content))
                Toast.makeText(this, "Translation copied!", Toast.LENGTH_SHORT).show()
            }
        }

        btnSpeakHindi.setOnClickListener {
            val displayText = tvHindi.text?.toString().orEmpty()
            val speakSource = rawHindiText.ifBlank { displayText }
            if (speakSource.isNotBlank()) {
                speakText(speakSource, Locale("hi", "IN"), displayText)
            }
        }

        // Dismiss ONLY the bottom 2-card popup
        btnClose.setOnClickListener {
            dismissTranslationPopup()
            refreshOverlayCallback?.invoke()
        }

        scrollView.post {
            runCatching {
                if (!root.isAttachedToWindow) return@runCatching
                val maxScrollH = (screenH * 0.50).toInt().coerceAtLeast(dp(180))
                if (scrollView.height > maxScrollH) {
                    val lp = scrollView.layoutParams
                    lp.height = maxScrollH
                    scrollView.layoutParams = lp
                }
            }
        }

        runCatching {
            windowManager.addView(root, params)
            translationPopupView = root
            translationPopupParams = params
        }.onFailure {
            Toast.makeText(this, "Could not display translation popup", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dismissTranslationPopup() {
        // Keep ongoing TTS voice reading continuously even after closing popup with X
        translationPopupView?.let { view ->
            runCatching {
                if (view.isAttachedToWindow) {
                    windowManager.removeView(view)
                } else {
                    windowManager.removeViewImmediate(view)
                }
            }
        }
        translationPopupView = null
        translationPopupParams = null
    }

    private fun closeAllTranslationOverlays() {
        dismissTranslationPopup()
        screenOverlayView?.let { runCatching { windowManager.removeView(it) } }
        screenOverlayView = null
        refreshOverlayCallback = null
        if (!isHiddenToNotification) {
            bubbleView?.visibility = View.VISIBLE
        }
    }

    private fun toggleManualPopup() {
        if (popupView != null) {
            closeManualPopup()
            return
        }
        if (!Settings.canDrawOverlays(this)) return

        val view = runCatching {
            LayoutInflater.from(themedContext).inflate(R.layout.overlay_popup, null)
        }.getOrElse {
            Toast.makeText(this, "Could not open translator popup", Toast.LENGTH_SHORT).show()
            return
        }

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.90).toInt().coerceAtLeast(300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val btnEasy = view.findViewById<Button>(R.id.btnModeEasy)
        val btnRoman = view.findViewById<Button>(R.id.btnModeRoman)
        val btnHinglish = view.findViewById<Button>(R.id.btnModeHinglish)
        val btnOcr = view.findViewById<Button>(R.id.btnPopupOcr)
        val btnPaste = view.findViewById<Button>(R.id.btnPopupPaste)
        val btnCopy = view.findViewById<Button>(R.id.btnPopupCopy)
        val btnClear = view.findViewById<Button>(R.id.btnPopupClear)
        val btnAgain = view.findViewById<Button>(R.id.btnPopupAgain)
        val btnHide = view.findViewById<ImageButton>(R.id.btnPopupHide)
        val btnClose = view.findViewById<ImageButton>(R.id.btnPopupClose)
        val inputEdit = view.findViewById<EditText>(R.id.etPopupInput)
        val outputText = view.findViewById<TextView>(R.id.tvPopupOutput)

        inputEdit.setText(lastEnglishText)

        fun styleModeBtn(btn: Button, active: Boolean) {
            btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (active) 0xFF2563EB.toInt() else 0xFFE2E8F0.toInt()
            )
            btn.setTextColor(if (active) 0xFFFFFFFF.toInt() else 0xFF0F172A.toInt())
        }

        fun refreshModeButtons() {
            styleModeBtn(btnEasy, currentMode == TranslationMode.EASY_HINDI)
            styleModeBtn(btnRoman, currentMode == TranslationMode.ROMAN_HINDI)
            styleModeBtn(btnHinglish, currentMode == TranslationMode.HINGLISH)
        }
        refreshModeButtons()

        fun translateNow(source: String) {
            val clean = source.trim()
            if (clean.isEmpty()) return
            lastEnglishText = clean
            outputText.text = "Translating..."
            scope.launch {
                try {
                    val res = withContext(Dispatchers.IO) {
                        translatorEngine.translate(clean, currentMode, dictionaryStore.getEntries())
                    }
                    outputText.text = res.translatedText
                } catch (ex: Exception) {
                    outputText.text = "Could not translate right now (${ex.localizedMessage ?: "try again"})."
                }
            }
        }

        btnEasy.setOnClickListener {
            currentMode = TranslationMode.EASY_HINDI
            dictionaryStore.setDefaultMode(currentMode)
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }
        btnRoman.setOnClickListener {
            currentMode = TranslationMode.ROMAN_HINDI
            dictionaryStore.setDefaultMode(currentMode)
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }
        btnHinglish.setOnClickListener {
            currentMode = TranslationMode.HINGLISH
            dictionaryStore.setDefaultMode(currentMode)
            refreshModeButtons()
            translateNow(inputEdit.text.toString())
        }

        btnOcr.setOnClickListener {
            closeManualPopup()
            triggerInstantScreenTranslate()
        }

        btnPaste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val primary = cm.primaryClip
            val clipText = if (primary != null && primary.itemCount > 0) {
                primary.getItemAt(0).coerceToText(this)?.toString().orEmpty()
            } else {
                ""
            }
            if (clipText.isNotBlank()) {
                inputEdit.setText(clipText)
                translateNow(clipText)
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            }
        }

        btnCopy.setOnClickListener {
            val translated = outputText.text.toString()
            if (translated.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("EasyHinglish", translated))
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show()
            }
        }

        btnClear.setOnClickListener {
            lastEnglishText = ""
            inputEdit.setText("")
            outputText.text = ""
        }

        btnAgain.setOnClickListener {
            translateNow(inputEdit.text.toString())
        }

        btnHide.setOnClickListener {
            closeManualPopup()
            isHiddenToNotification = true
            bubbleView?.visibility = View.GONE
            Toast.makeText(this, "Bubble hidden. Tap notification to show again.", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener {
            stopSelf()
        }

        runCatching {
            windowManager.addView(view, params)
            popupView = view
            popupParams = params
        }.onFailure {
            Toast.makeText(this, "Could not open floating popup", Toast.LENGTH_SHORT).show()
        }
    }

    private fun closeManualPopup() {
        popupView?.let { runCatching { windowManager.removeView(it) } }
        popupView = null
        popupParams = null
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    companion object {
        @Volatile
        var isRunning: Boolean = false
        const val CHANNEL_ID = "easy_hinglish_overlay_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.easyhinglish.translator.STOP"
        const val ACTION_STOP_VOICE = "com.easyhinglish.translator.STOP_VOICE"
        const val ACTION_SHOW_BUBBLE = "com.easyhinglish.translator.SHOW_BUBBLE"
        const val ACTION_OPEN_MANUAL_POPUP = "com.easyhinglish.translator.OPEN_MANUAL_POPUP"
        const val ACTION_SET_PROJECTION = "com.easyhinglish.translator.SET_PROJECTION"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA_INTENT = "data_intent"
    }
}
