package com.easyhinglish.translator.data

import android.content.Context
import com.easyhinglish.translator.model.DictionaryEntry
import com.easyhinglish.translator.model.TranslationMode
import org.json.JSONArray
import org.json.JSONObject

class DictionaryStore(context: Context) {
    private val prefs = context.getSharedPreferences("easy_hinglish_prefs", Context.MODE_PRIVATE)

    fun getDefaultMode(): TranslationMode {
        val raw = prefs.getString("default_mode", TranslationMode.ROMAN_HINDI.name)
        return runCatching { TranslationMode.valueOf(raw ?: "") }.getOrDefault(TranslationMode.ROMAN_HINDI)
    }

    fun setDefaultMode(mode: TranslationMode) {
        prefs.edit().putString("default_mode", mode.name).apply()
    }

    fun getEntries(): List<DictionaryEntry> {
        val json = prefs.getString("dictionary_json", null) ?: return defaultEntries()
        return try {
            val arr = JSONArray(json)
            val list = mutableListOf<DictionaryEntry>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    DictionaryEntry(
                        id = obj.getString("id"),
                        sourceWord = obj.getString("sourceWord"),
                        easyWord = obj.getString("easyWord"),
                        devanagariEasy = obj.optString("devanagariEasy", ""),
                        enabled = obj.optBoolean("enabled", true)
                    )
                )
            }
            list
        } catch (_: Exception) {
            defaultEntries()
        }
    }

    fun saveEntries(entries: List<DictionaryEntry>) {
        val arr = JSONArray()
        for (item in entries) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("sourceWord", item.sourceWord)
            obj.put("easyWord", item.easyWord)
            obj.put("devanagariEasy", item.devanagariEasy)
            obj.put("enabled", item.enabled)
            arr.put(obj)
        }
        prefs.edit().putString("dictionary_json", arr.toString()).apply()
    }

    fun addOrUpdate(sourceWord: String, easyWord: String, devanagariEasy: String = "") {
        val current = getEntries().toMutableList()
        val existingIdx = current.indexOfFirst { it.sourceWord.equals(sourceWord.trim(), ignoreCase = true) }
        val entry = DictionaryEntry(
            id = if (existingIdx >= 0) current[existingIdx].id else "dict_${System.currentTimeMillis()}",
            sourceWord = sourceWord.trim(),
            easyWord = easyWord.trim(),
            devanagariEasy = devanagariEasy.trim(),
            enabled = true
        )
        if (existingIdx >= 0) {
            current[existingIdx] = entry
        } else {
            current.add(0, entry)
        }
        saveEntries(current)
    }

    fun deleteById(id: String) {
        saveEntries(getEntries().filterNot { it.id == id })
    }

    fun resetDefaults() {
        saveEntries(defaultEntries())
    }

    companion object {
        fun defaultEntries(): List<DictionaryEntry> = listOf(
            DictionaryEntry("d1", "सहायता", "Madad", "मदद", true),
            DictionaryEntry("d2", "आवश्यक", "Zaroori", "ज़रूरी", true),
            DictionaryEntry("d3", "अत्यधिक", "Bahut zyada", "बहुत ज़्यादा", true),
            DictionaryEntry("d4", "समस्या", "Pareshani", "परेशानी", true),
            DictionaryEntry("d5", "प्रतीक्षा", "Intezaar", "इंतज़ार", true),
            DictionaryEntry("d6", "कठिन", "Mushkil", "मुश्किल", true),
            DictionaryEntry("d7", "निर्णय", "Faisla", "फैसला", true),
            DictionaryEntry("d8", "प्रारंभ", "Shuru", "शुरू", true),
            DictionaryEntry("d9", "संपूर्ण", "Poora", "पूरा", true),
            DictionaryEntry("d10", "तत्काल", "Turant", "तुरंत", true),
            DictionaryEntry("d11", "सुरक्षित", "Safe", "सेफ़", true)
        )
    }
}
