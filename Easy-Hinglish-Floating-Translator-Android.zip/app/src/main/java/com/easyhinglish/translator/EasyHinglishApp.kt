package com.easyhinglish.translator

import android.app.Application
import java.io.PrintWriter
import java.io.StringWriter

class EasyHinglishApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                getSharedPreferences("easy_hinglish_prefs", MODE_PRIVATE)
                    .edit()
                    .putString("last_crash_log", sw.toString().take(4000))
                    .commit()
            }
            previous?.uncaughtException(thread, throwable)
        }
    }
}
