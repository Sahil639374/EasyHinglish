package com.easyhinglish.translator.translation

import com.easyhinglish.translator.model.DictionaryEntry
import com.easyhinglish.translator.model.OcrTextBlock
import com.easyhinglish.translator.model.TranslatedOverlayBlock
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.model.TranslationResult
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslatorEngine {
    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.HINDI)
        .build()

    private var clientInstance: com.google.mlkit.nl.translate.Translator? = null
    private val client: com.google.mlkit.nl.translate.Translator
        get() = clientInstance ?: Translation.getClient(options).also { clientInstance = it }

    @Volatile
    private var modelReady = false

    @Volatile
    private var modelCheckedOnce = false

    private val downloadStarted = AtomicBoolean(false)
    private val rawHindiCache = ConcurrentHashMap<String, String>()

    private fun cacheRawHindi(source: String, hindi: String) {
        if (source.isBlank() || hindi.isBlank()) return
        if (rawHindiCache.size >= 500) {
            rawHindiCache.clear()
        }
        rawHindiCache[source] = hindi
    }

    suspend fun isHindiPackDownloaded(): Boolean {
        if (modelReady) return true
        if (modelCheckedOnce) return false
        return suspendCancellableCoroutine { cont ->
            val model = TranslateRemoteModel.Builder(TranslateLanguage.HINDI).build()
            RemoteModelManager.getInstance().isModelDownloaded(model)
                .addOnSuccessListener { downloaded ->
                    modelCheckedOnce = true
                    if (downloaded) modelReady = true
                    if (cont.isActive) cont.resume(downloaded)
                }
                .addOnFailureListener {
                    modelCheckedOnce = true
                    if (cont.isActive) cont.resume(false)
                }
        }
    }

    fun startBackgroundModelDownload() {
        if (modelReady || !downloadStarted.compareAndSet(false, true)) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            client.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    modelReady = true
                    modelCheckedOnce = true
                }
                .addOnFailureListener { downloadStarted.set(false) }
        }.onFailure {
            downloadStarted.set(false)
        }
    }

    suspend fun ensureModelReady() {
        if (modelReady) return
        val conditions = DownloadConditions.Builder().build()
        suspendCancellableCoroutine<Unit> { cont ->
            client.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    modelReady = true
                    modelCheckedOnce = true
                    if (cont.isActive) cont.resume(Unit)
                }
                .addOnFailureListener { ex ->
                    modelCheckedOnce = true
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    private suspend fun translateWithMlKit(cleaned: String): String {
        return suspendCancellableCoroutine { cont ->
            client.translate(cleaned)
                .addOnSuccessListener { result ->
                    if (cont.isActive) cont.resume(result)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    private suspend fun translateViaNetworkFast(cleaned: String): String? = coroutineScope {
        val c5Job = async(Dispatchers.IO) {
            runCatching { translateInChunks(cleaned, 1400, ::fetchGoogleClients5) }.getOrNull()
        }

        // Wait briefly for primary Google Translate; only hedge with backup if slower than 450ms
        val fastWaitJob = async(Dispatchers.IO) {
            delay(450L)
            null as String?
        }

        val quickWinner = select<String?> {
            c5Job.onAwait { it }
            fastWaitJob.onAwait { null }
        }
        fastWaitJob.cancel()

        if (!quickWinner.isNullOrBlank()) {
            return@coroutineScope quickWinner
        }

        val gtxJob = async(Dispatchers.IO) {
            runCatching { translateInChunks(cleaned, 1400, ::fetchGoogleGtx) }.getOrNull()
        }

        val firstValid = select<String?> {
            c5Job.onAwait { res ->
                if (!res.isNullOrBlank()) res else gtxJob.await()
            }
            gtxJob.onAwait { res ->
                if (!res.isNullOrBlank()) res else c5Job.await()
            }
        }
        if (!firstValid.isNullOrBlank()) {
            c5Job.cancel()
            gtxJob.cancel()
            return@coroutineScope firstValid
        }

        // Tier 4: Free MyMemory endpoint fallback
        withContext(Dispatchers.IO) {
            runCatching { translateInChunks(cleaned, 450, ::fetchMyMemory) }.getOrNull()
        }
    }

    private suspend fun translateRawHindi(cleaned: String): String {
        rawHindiCache[cleaned]?.let { return it }

        // Tier 1: Instant on-device ML Kit if already downloaded
        if (isHindiPackDownloaded()) {
            val mlResult = runCatching { translateWithMlKit(cleaned) }.getOrNull()
            if (!mlResult.isNullOrBlank()) {
                cacheRawHindi(cleaned, mlResult)
                return mlResult
            }
        } else {
            // Silent background warm-up without blocking user
            startBackgroundModelDownload()
        }

        // Tier 2/3/4: Ultra-fast hedged HTTPS translation
        val netResult = translateViaNetworkFast(cleaned)
        if (!netResult.isNullOrBlank()) {
            cacheRawHindi(cleaned, netResult)
            return netResult
        }

        // Tier 5: Local zero-network phrase fallback so popup still opens cleanly offline
        return offlineLocalFallback(cleaned)
    }

    private fun translateInChunks(
        text: String,
        maxChunkChars: Int,
        fetcher: (String) -> String?
    ): String? {
        if (text.length <= maxChunkChars) return fetcher(text)
        val lines = text.split("\n")
        val chunks = mutableListOf<String>()
        val current = StringBuilder()
        for (line in lines) {
            if (current.isNotEmpty() && current.length + line.length + 1 > maxChunkChars) {
                chunks.add(current.toString())
                current.clear()
            }
            if (line.length > maxChunkChars) {
                if (current.isNotEmpty()) {
                    chunks.add(current.toString())
                    current.clear()
                }
                chunks.add(line.take(maxChunkChars))
            } else {
                if (current.isNotEmpty()) current.append('\n')
                current.append(line)
            }
        }
        if (current.isNotEmpty()) chunks.add(current.toString())

        val out = StringBuilder()
        for (chunk in chunks) {
            val translated = fetcher(chunk) ?: return null
            if (out.isNotEmpty()) out.append('\n')
            out.append(translated)
        }
        return out.toString().trim().takeIf { it.isNotEmpty() }
    }

    private fun fetchGoogleClients5(query: String): String? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=en&tl=hi&q=$encoded")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 2200
            readTimeout = 3000
            requestMethod = "GET"
            setRequestProperty("Connection", "keep-alive")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (!body.startsWith("[")) return null
            val arr = JSONArray(body)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val item = arr.opt(i)
                when (item) {
                    is String -> sb.append(item)
                    is JSONArray -> sb.append(item.optString(0, ""))
                }
            }
            sb.toString().trim().takeIf { it.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchGoogleGtx(query: String): String? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=hi&dt=t&q=$encoded")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 2200
            readTimeout = 3000
            requestMethod = "GET"
            setRequestProperty("Connection", "keep-alive")
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (!body.startsWith("[")) return null
            val root = JSONArray(body)
            val sentences = root.optJSONArray(0) ?: return null
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                sb.append(sentences.optJSONArray(i)?.optString(0, "").orEmpty())
            }
            sb.toString().trim().takeIf { it.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchMyMemory(query: String): String? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://api.mymemory.translated.net/get?q=$encoded&langpair=en|hi")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 2500
            readTimeout = 3500
            requestMethod = "GET"
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            val obj = JSONObject(body)
            val status = obj.optInt("responseStatus", 0)
            if (status != 200) return null
            obj.optJSONObject("responseData")?.optString("translatedText", "")?.trim()
                ?.takeIf { it.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun offlineLocalFallback(text: String): String {
        val wordMap = mapOf(
            "wait a minute" to "एक मिनट रुको",
            "we need your help" to "हमें आपकी मदद चाहिए",
            "right away" to "तुरंत",
            "problem" to "समस्या",
            "help" to "मदद",
            "settings" to "सेटिंग्स",
            "download" to "डाउनलोड",
            "search" to "खोजें",
            "continue" to "जारी रखें",
            "cancel" to "रद्द करें",
            "confirm" to "पक्का करें",
            "start" to "शुरू करें",
            "next" to "अगला",
            "back" to "वापस",
            "open" to "खोलें",
            "close" to "बंद करें",
            "save" to "सेव करें"
        )
        var out = text
        for ((en, hi) in wordMap) {
            out = out.replace(Regex("\\b${Regex.escape(en)}\\b", RegexOption.IGNORE_CASE), hi)
        }
        return out
    }

    fun formatHindiForMode(
        rawHindi: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): Pair<String, List<String>> {
        val applied = mutableListOf<String>()
        val useDevanagari = mode == TranslationMode.EASY_HINDI
        var processed = rawHindi

        for (entry in dictionary) {
            if (!entry.enabled || entry.sourceWord.isBlank() || entry.easyWord.isBlank()) continue
            val target = if (useDevanagari && entry.devanagariEasy.isNotBlank()) {
                entry.devanagariEasy
            } else {
                entry.easyWord
            }
            if (processed.contains(entry.sourceWord, ignoreCase = true)) {
                processed = processed.replace(entry.sourceWord, target, ignoreCase = true)
                applied.add("${entry.sourceWord} -> $target")
            }
        }

        val finalOutput = when (mode) {
            TranslationMode.EASY_HINDI -> simplifyDevanagari(processed, useEnglishMix = false)
            TranslationMode.ROMAN_HINDI -> transliterateToRoman(simplifyDevanagari(processed, useEnglishMix = false))
            TranslationMode.HINGLISH -> transliterateToRoman(simplifyDevanagari(processed, useEnglishMix = true))
        }
        return finalOutput to applied
    }

    suspend fun translateWithRaw(
        englishText: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): Pair<String, TranslationResult> {
        val cleaned = englishText.trim()
        if (cleaned.isEmpty()) {
            return "" to TranslationResult("", "", mode, emptyList())
        }
        val rawHindi = translateRawHindi(cleaned)
        val (finalOutput, applied) = formatHindiForMode(rawHindi, mode, dictionary)
        return rawHindi to TranslationResult(
            sourceText = cleaned,
            translatedText = finalOutput,
            mode = mode,
            appliedRules = applied
        )
    }

    suspend fun translate(
        englishText: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): TranslationResult {
        return translateWithRaw(englishText, mode, dictionary).second
    }

    suspend fun translateBlocks(
        blocks: List<OcrTextBlock>,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): List<TranslatedOverlayBlock> {
        val cleanBlocks = blocks.mapNotNull { block ->
            val clean = block.text.replace(Regex("\\s+"), " ").trim()
            if (clean.length < 2) null else block to clean
        }
        if (cleanBlocks.isEmpty()) return emptyList()

        val rawMap = HashMap<String, String>(cleanBlocks.size)
        val uncached = mutableListOf<String>()
        val seenUncached = HashSet<String>()

        for ((_, clean) in cleanBlocks) {
            val cached = rawHindiCache[clean]
            if (cached != null) {
                rawMap[clean] = cached
            } else if (seenUncached.add(clean)) {
                uncached.add(clean)
            }
        }

        // Fast Path: Single joined request for all uncached blocks when total <= 1400 chars
        if (uncached.size >= 2) {
            val joined = uncached.joinToString("\n")
            if (joined.length <= 1400) {
                val batchRaw = runCatching { translateRawHindi(joined) }.getOrNull()
                if (!batchRaw.isNullOrBlank()) {
                    val lines = batchRaw.split("\n").map { it.trim() }
                    if (lines.size == uncached.size && lines.all { it.isNotEmpty() }) {
                        uncached.forEachIndexed { idx, src ->
                            val hi = lines[idx]
                            rawMap[src] = hi
                            cacheRawHindi(src, hi)
                        }
                    }
                }
            }
        }

        // Parallel fallback for any remaining uncached blocks
        val remaining = uncached.filter { !rawMap.containsKey(it) }
        if (remaining.isNotEmpty()) {
            coroutineScope {
                val jobs = remaining.map { src ->
                    async(Dispatchers.IO) {
                        val hi = runCatching { translateRawHindi(src) }.getOrNull()
                        src to hi
                    }
                }
                jobs.awaitAll().forEach { (src, hi) ->
                    if (!hi.isNullOrBlank()) {
                        rawMap[src] = hi
                    }
                }
            }
        }

        val out = mutableListOf<TranslatedOverlayBlock>()
        for ((block, clean) in cleanBlocks) {
            val rawHindi = rawMap[clean] ?: continue
            val (formatted, _) = formatHindiForMode(rawHindi, mode, dictionary)
            if (formatted.isNotBlank()) {
                out.add(
                    TranslatedOverlayBlock(
                        sourceText = clean,
                        rawHindiText = rawHindi,
                        translatedText = formatted,
                        left = block.left,
                        top = block.top,
                        right = block.right,
                        bottom = block.bottom
                    )
                )
            }
        }
        return out
    }

    fun close() {
        runCatching { clientInstance?.close() }
        clientInstance = null
    }

    private fun simplifyDevanagari(input: String, useEnglishMix: Boolean): String {
        val sb = StringBuilder(input.length)
        var i = 0
        while (i < input.length) {
            if (isDevanagari(input[i])) {
                val start = i
                while (i < input.length && isDevanagari(input[i])) i++
                val word = input.substring(start, i)
                val replaced = if (useEnglishMix) {
                    lookupHinglishWord(word) ?: lookupSimpleHindiWord(word) ?: word
                } else {
                    lookupSimpleHindiWord(word) ?: word
                }
                sb.append(replaced)
            } else {
                sb.append(input[i])
                i++
            }
        }
        return sb.toString().replace(Regex("[ \\t]+"), " ").trim()
    }

    private fun lookupHinglishWord(word: String): String? {
        hinglishWordMap[word]?.let { return it }
        // Try common Hindi plural/oblique suffixes (-ओं, -यों, -ओं, -एं)
        for (suffix in listOf("ओं", "यों", "याँ", "यां", "एँ", "एं")) {
            if (word.length > suffix.length + 2 && word.endsWith(suffix)) {
                val stem = word.removeSuffix(suffix)
                hinglishWordMap[stem]?.let { return it }
                hinglishWordMap["${stem}ा"]?.let { return it }
                hinglishWordMap["${stem}ि"]?.let { return it }
                hinglishWordMap["${stem}ी"]?.let { return it }
            }
        }
        return null
    }

    private fun lookupSimpleHindiWord(word: String): String? {
        return simpleDevanagariMap[word]
    }

    private fun transliterateToRoman(input: String): String {
        val out = StringBuilder(input.length + 16)
        var i = 0
        while (i < input.length) {
            if (isDevanagari(input[i])) {
                val start = i
                while (i < input.length && isDevanagari(input[i])) i++
                val word = input.substring(start, i)
                out.append(commonRomanWords[word] ?: phoneticDevanagariToRoman(word))
            } else {
                val ch = input[i]
                out.append(if (ch == '।') '.' else ch)
                i++
            }
        }
        return out.toString()
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun phoneticDevanagariToRoman(pre: String): String {
        val digraphs = listOf(
            "क्ष" to "ksh", "त्र" to "tr", "ज्ञ" to "gy", "श्र" to "shr",
            "ज़" to "z", "फ़" to "f", "क़" to "q", "ख़" to "kh", "ग़" to "gh", "ड़" to "d", "ढ़" to "dh"
        )
        val consonants = mapOf(
            'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
            'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
            'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
            'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
            'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
            'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
            'ष' to "sh", 'स' to "s", 'ह' to "h"
        )
        val vowels = mapOf(
            'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "oo",
            'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o"
        )
        val matras = mapOf(
            'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "oo",
            'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
            'ॉ' to "o", 'ॅ' to "e",
            'ं' to "n", 'ँ' to "n", 'ः' to "h", '्' to ""
        )

        val sb = StringBuilder()
        var i = 0
        while (i < pre.length) {
            var matchedDigraph = false
            for ((dg, romanBase) in digraphs) {
                if (pre.startsWith(dg, i)) {
                    val afterPos = i + dg.length
                    val next = pre.getOrNull(afterPos)
                    if (next == '्') {
                        sb.append(romanBase)
                        i = afterPos + 1
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(romanBase).append(matras[next])
                        i = afterPos + 1
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-।"
                        sb.append(romanBase)
                        if (!isEnd) sb.append('a')
                        i = afterPos
                    }
                    matchedDigraph = true
                    break
                }
            }
            if (matchedDigraph) continue

            val ch = pre[i]
            when {
                ch == '।' -> sb.append('.')
                vowels.containsKey(ch) -> sb.append(vowels[ch])
                consonants.containsKey(ch) -> {
                    val base = consonants[ch]!!
                    val next = pre.getOrNull(i + 1)
                    if (next == '्') {
                        sb.append(base)
                        i++
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(base).append(matras[next])
                        i++
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-।"
                        sb.append(base)
                        if (!isEnd) sb.append('a')
                    }
                }
                matras.containsKey(ch) -> sb.append(matras[ch])
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString()
    }

    private fun isDevanagari(c: Char): Boolean = c in '\u0900'..'\u097F'

    companion object {
        // Replaces hard/formal/literary Devanagari words directly with clear English in Hinglish mode
        private val hinglishWordMap: Map<String, String> = mapOf(
            "ज्ञात" to "known", "अज्ञात" to "unknown",
            "सीमा" to "boundary", "सीमाओं" to "boundaries", "सीमाएं" to "boundaries", "सीमाएँ" to "boundaries",
            "परे" to "beyond", "अंतहीन" to "endless", "अनंत" to "endless",
            "आकाश" to "sky", "अंतरिक्ष" to "space", "ब्रह्मांड" to "universe",
            "साम्राज्य" to "kingdom", "राज्य" to "kingdom", "किंडम" to "kingdom", "किडम" to "kingdom",
            "मौजूद" to "present", "उपस्थित" to "present", "अनुपस्थित" to "absent",
            "समृद्ध" to "rich", "संपन्न" to "prosperous", "वैभव" to "glory",
            "प्राचीन" to "ancient", "ऐतिहासिक" to "historic", "पौराणिक" to "legendary",
            "आत्मा" to "spirit", "आत्माओं" to "spirits", "आत्माएं" to "spirits", "आत्माएँ" to "spirits",
            "प्रकृति" to "nature", "प्राकृतिक" to "natural",
            "रहस्य" to "secret", "रहस्यों" to "secrets", "रहस्यमय" to "mysterious", "रहस्यमयी" to "mysterious",
            "शक्ति" to "power", "शक्तियों" to "powers", "शक्तियां" to "powers", "शक्तियाँ" to "powers",
            "शक्तिशाली" to "powerful", "बलशाली" to "strong",
            "सद्भाव" to "harmony", "सद्भावना" to "harmony", "शांति" to "peace", "शांतिपूर्ण" to "peaceful",
            "हालांकि" to "lekin", "यद्यपि" to "although", "तथापि" to "still", "अर्थात" to "matlab",
            "स्वरूप" to "look", "आकार" to "shape", "दिखावा" to "appearance",
            "भयानक" to "scary", "भयंकर" to "terrible", "डरावना" to "scary", "खतरनाक" to "dangerous",
            "खतरा" to "danger", "संकट" to "crisis", "आपदा" to "disaster",
            "भविष्यवाणी" to "prophecy", "भविष्यवाणियों" to "prophecies", "भविष्य" to "future",
            "यात्री" to "traveler", "यात्रियों" to "travelers", "यात्रा" to "journey",
            "आगमन" to "arrival", "प्रवेश" to "entry", "निकास" to "exit",
            "पुनर्स्थापित" to "restore", "पुनर्निर्माण" to "rebuild", "पुनर्जन्म" to "rebirth",
            "पूर्ण" to "complete", "संपूर्ण" to "complete", "अपूर्ण" to "incomplete",
            "विनाश" to "destruction", "सर्वनाश" to "total destruction", "नष्ट" to "destroy",
            "सदी" to "century", "सदियाँ" to "centuries", "सदियां" to "centuries", "सदियों" to "centuries",
            "विस्मृति" to "oblivion", "लुप्त" to "vanish", "गायब" to "vanish", "अदृश्य" to "invisible",
            "अजनबी" to "stranger", "अपरिचित" to "stranger",
            "परित्यक्त" to "abandoned", "वीरान" to "abandoned",
            "द्वार" to "gate", "प्रवेशद्वार" to "entrance gate",
            "सुप्त" to "dormant", "जाग्रत" to "awake", "जीवित" to "alive", "मृत" to "dead",
            "अमर" to "immortal", "शापित" to "cursed", "अभिशाप" to "curse", "वरदान" to "blessing",
            "ईश्वर" to "God", "भगवान" to "God", "देवता" to "god", "देवी" to "goddess",
            "असुर" to "demon", "राक्षस" to "monster", "दानव" to "demon", "भूत" to "ghost",
            "संरक्षक" to "guardian", "रक्षक" to "protector", "योद्धा" to "warrior", "सैनिक" to "soldier",
            "सेना" to "army", "युद्ध" to "war", "लड़ाई" to "fight", "संघर्ष" to "battle",
            "आक्रमण" to "attack", "हमला" to "attack", "रक्षा" to "defense", "सुरक्षा" to "safety",
            "विजय" to "victory", "पराजय" to "defeat", "विजेता" to "winner",
            "शस्त्र" to "weapon", "हथियार" to "weapon", "तलवार" to "sword", "ढाल" to "shield", "कवच" to "armor",
            "जादू" to "magic", "जादुई" to "magical", "मंत्र" to "spell", "ऊर्जा" to "energy",
            "अंधकार" to "darkness", "प्रकाश" to "light", "उजाला" to "light", "छाया" to "shadow",
            "सिंहासन" to "throne", "मुकुट" to "crown", "खजाना" to "treasure", "रत्न" to "gem",
            "किला" to "fort", "महल" to "palace", "मंदिर" to "temple", "संसार" to "world",
            "सत्य" to "truth", "असत्य" to "lie", "न्याय" to "justice", "अन्याय" to "injustice",
            "विश्वास" to "trust", "अविश्वास" to "doubt", "संदेह" to "doubt", "धोखा" to "betrayal",
            "क्षमता" to "ability", "कौशल" to "skill", "अनुभव" to "experience", "स्तर" to "level",
            "उपलब्धि" to "achievement", "पुरस्कार" to "reward", "इनाम" to "reward", "चुनौती" to "challenge",
            "लक्ष्य" to "target", "उद्देश्य" to "purpose", "अभियान" to "mission", "कार्य" to "task",
            "प्रभाव" to "effect", "परिणाम" to "result", "कारण" to "reason", "अस्तित्व" to "existence",
            "नियंत्रण" to "control", "स्वतंत्रता" to "freedom", "आजादी" to "freedom", "अधिकार" to "right",
            "संदेश" to "message", "संकेत" to "signal", "चेतावनी" to "warning", "सूचना" to "notice",
            "जानकारी" to "details", "विवरण" to "details", "स्थिति" to "status", "परिस्थिति" to "situation",
            "समस्या" to "problem", "परेशानी" to "problem", "समाधान" to "solution",
            "प्रयास" to "try", "कोशिश" to "try", "प्रतीक्षा" to "wait", "इंतज़ार" to "wait",
            "निर्णय" to "decision", "फैसला" to "decision", "चयन" to "select", "विकल्प" to "option",
            "आवश्यक" to "important", "अनिवार्य" to "required", "महत्वपूर्ण" to "important",
            "अद्भुत" to "amazing", "अविश्वसनीय" to "unbelievable", "असाधारण" to "special",
            "विशेष" to "special", "सामान्य" to "normal", "मुख्य" to "main", "अतिरिक्त" to "extra",
            "संभव" to "possible", "असंभव" to "impossible", "निश्चित" to "confirm", "अनिश्चित" to "uncertain",
            "सफल" to "success", "सफलता" to "success", "असफल" to "fail", "विफल" to "fail",
            "प्रारंभ" to "start", "शुरुआत" to "start", "समाप्त" to "finish", "अंत" to "end",
            "निरंतर" to "continuous", "लगातार" to "continuous", "तत्काल" to "turant", "शीघ्र" to "jaldi",
            "कृपया" to "please", "धन्यवाद" to "thanks", "शुक्रिया" to "thanks", "क्षमा" to "sorry",
            "अनुमति" to "permission", "सहायता" to "help", "मदद" to "help", "सुरक्षित" to "safe",
            "पुष्टि" to "confirm", "रद्द" to "cancel", "जारी" to "continue", "सहेजें" to "save",
            "खोजें" to "search", "हटाएं" to "delete", "जोड़ें" to "add", "बदलें" to "change",
            "उपकरण" to "device", "सामग्री" to "material", "वस्तु" to "item", "अध्याय" to "chapter",
            "कठिन" to "hard", "सरल" to "easy", "आसान" to "easy", "समय" to "time", "क्षण" to "moment",
            "सपना" to "dream", "स्वप्न" to "dream", "स्मृति" to "memory", "भाग्य" to "luck",
            "दुर्भाग्य" to "bad luck", "सौभाग्य" to "good luck", "आश्चर्य" to "surprise", "क्रोध" to "anger",
            "भय" to "fear", "आशा" to "hope", "निराशा" to "hopeless", "प्रसन्न" to "happy",
            "दुखी" to "sad", "चिंतित" to "worried", "क्रूर" to "cruel", "दयालु" to "kind",
            "ईमानदार" to "honest", "बुद्धिमान" to "smart", "मूर्ख" to "foolish", "प्रसिद्ध" to "famous"
        )

        // Everyday simple Hindi words (in Devanagari) used for Roman & Easy Hindi modes
        private val simpleDevanagariMap: Map<String, String> = mapOf(
            "ज्ञात" to "जाना-माना", "अज्ञात" to "अनजान",
            "सीमा" to "हद", "सीमाओं" to "हदों",
            "अंतहीन" to "बेहद लंबा", "आकाश" to "आसमान",
            "साम्राज्य" to "राज्य", "समृद्ध" to "अमीर और खुशहाल",
            "प्राचीन" to "बहुत पुराना", "आत्मा" to "रूह", "आत्माओं" to "रूहों",
            "प्रकृति" to "कुदरत", "रहस्यमय" to "राज़ से भरा", "रहस्य" to "राज़",
            "सद्भाव" to "प्यार", "हालांकि" to "लेकिन",
            "शांतिपूर्ण" to "शांत", "स्वरूप" to "रूप",
            "भयानक" to "खतरनाक", "भयंकर" to "बहुत खतरनाक",
            "भविष्यवाणी" to "आगे की बात", "यात्री" to "मुसाफिर", "आगमन" to "आना",
            "पुनर्स्थापित" to "फिर से ठीक", "पूर्ण" to "पूरा", "संपूर्ण" to "पूरा",
            "विनाश" to "तबाही", "सदियाँ" to "सालों", "सदियां" to "सालों", "सदियों" to "सालों",
            "विस्मृति" to "भूल", "लुप्त" to "गायब",
            "अजनबी" to "अनजान आदमी", "परित्यक्त" to "सुनसान", "द्वार" to "दरवाज़ा",
            "सुप्त" to "सोया हुआ", "अत्यधिक" to "बहुत ज़्यादा", "तत्काल" to "तुरंत",
            "शीघ्र" to "जल्दी", "प्रतीक्षा" to "इंतज़ार", "प्रारंभ" to "शुरू",
            "समाप्त" to "खत्म", "निर्णय" to "फैसला", "सहायता" to "मदद",
            "आवश्यक" to "ज़रूरी", "कठिन" to "मुश्किल", "सरल" to "आसान",
            "प्रतीत" to "लगना", "अवश्य" to "ज़रूर", "प्रयास" to "कोशिश",
            "किंडम" to "राज्य", "किडम" to "राज्य"
        )

        // Everyday Bolchal Roman Hindi spellings (prevents awkward aa/ee & schwa issues)
        private val commonRomanWords: Map<String, String> = mapOf(
            "मैं" to "main", "हूँ" to "hoon", "हूं" to "hoon", "है" to "hai", "हैं" to "hain",
            "था" to "tha", "थी" to "thi", "थे" to "the", "थीं" to "thi",
            "नहीं" to "nahi", "और" to "aur", "में" to "mein", "पर" to "par", "से" to "se",
            "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke", "ने" to "ne",
            "यह" to "yeh", "वह" to "woh", "ये" to "ye", "वो" to "wo",
            "इस" to "is", "उस" to "us", "एक" to "ek", "दो" to "do", "तीन" to "teen",
            "आप" to "aap", "तुम" to "tum", "हम" to "hum", "क्या" to "kya", "क्यों" to "kyon",
            "बहुत" to "bahut", "ज़्यादा" to "zyada", "ज्यादा" to "zyada", "कम" to "kam",
            "पहले" to "pehle", "बाद" to "baad", "अभी" to "abhi", "तब" to "tab", "जब" to "jab",
            "अगर" to "agar", "लेकिन" to "lekin", "क्योंकि" to "kyunki", "इसलिए" to "isliye",
            "यहाँ" to "yahan", "यहां" to "yahan", "वहाँ" to "wahan", "वहां" to "wahan",
            "कहाँ" to "kahan", "कहां" to "kahan", "कैसे" to "kaise", "कौन" to "kaun",
            "कुछ" to "kuch", "कोई" to "koi", "सभी" to "sabhi", "सब" to "sab",
            "अपने" to "apne", "अपनी" to "apni", "अपना" to "apna", "साथ" to "saath",
            "पास" to "paas", "दूर" to "door", "नीचे" to "neeche", "ऊपर" to "oopar",
            "अंदर" to "andar", "बाहर" to "baahar", "आगे" to "aage", "पीछे" to "peechhe", "बीच" to "beech",
            "दुनिया" to "duniya", "ज़िंदगी" to "zindagi", "जिंदगी" to "zindagi",
            "लोग" to "log", "बात" to "baat", "दिन" to "din", "रात" to "raat",
            "नाम" to "naam", "काम" to "kaam", "पैसा" to "paisa", "पैसे" to "paise",
            "मदद" to "madad", "ज़रूरी" to "zaroori", "जरूरी" to "zaroori",
            "परेशानी" to "pareshani", "इंतज़ार" to "intezaar", "इंतजार" to "intezaar",
            "कृपया" to "kripya", "धन्यवाद" to "dhanyawad", "शुक्रिया" to "shukriya",
            "अच्छा" to "achha", "अच्छे" to "achhe", "अच्छी" to "achhi", "ठीक" to "theek",
            "बड़ा" to "bada", "बड़े" to "bade", "बड़ी" to "badi",
            "छोटा" to "chhota", "छोटे" to "chhote", "छोटी" to "chhoti",
            "पुराना" to "purana", "पुरानी" to "purani", "नया" to "naya", "नयी" to "nayi", "नई" to "nayi",
            "रहा" to "raha", "रही" to "rahi", "रहे" to "rahe",
            "गया" to "gaya", "गयी" to "gayi", "गई" to "gayi", "गए" to "gaye", "गईं" to "gayi",
            "हुआ" to "hua", "हुई" to "hui", "हुए" to "hue",
            "लिया" to "liya", "दिया" to "diya", "किया" to "kiya",
            "करना" to "karna", "करने" to "karne", "करके" to "karke",
            "करता" to "karta", "करती" to "karti", "करते" to "karte",
            "रहता" to "rehta", "रहती" to "rehti", "रहते" to "rehte",
            "होता" to "hota", "होती" to "hoti", "होते" to "hote",
            "होगा" to "hoga", "होगी" to "hogi", "होंगे" to "honge",
            "सकता" to "sakta", "सकती" to "sakti", "सकते" to "sakte", "चाहिए" to "chahiye",
            "दिखाई" to "dikhai", "सुनाई" to "sunai", "बताया" to "bataya", "बनाया" to "banaya",
            "मिला" to "mila", "देखा" to "dekha", "सोचा" to "socha", "बोला" to "bola", "पूछा" to "poochha",
            "लगा" to "laga", "लगी" to "lagi", "लगे" to "lage",
            "लगता" to "lagta", "लगती" to "lagti", "लगते" to "lagte",
            "छिपा" to "chhipa", "छुपा" to "chhupa", "बचा" to "bacha",
            "जाना-माना" to "jaana-mana", "अनजान" to "anjaan", "सुनसान" to "sunsaan",
            "दरवाज़ा" to "darwaza", "दरवाजा" to "darwaza", "आसमान" to "aasmaan",
            "तबाही" to "tabaahi", "मुसाफिर" to "musafir", "राज़" to "raaz",
            "खुशहाल" to "khushhaal", "अमीर" to "ameer", "खत्म" to "khatam",
            "उसके" to "uske", "उसका" to "uska", "उसकी" to "uski", "उसने" to "usne", "उसमें" to "usmein",
            "इसके" to "iske", "इसका" to "iska", "इसकी" to "iski", "इसमें" to "ismein",
            "जिसके" to "jiske", "जिसका" to "jiska", "जिसकी" to "jiski", "जिसने" to "jisne",
            "उनके" to "unke", "उनका" to "unka", "उनकी" to "unki", "उन्होंने" to "unhone",
            "मेरा" to "mera", "मेरी" to "meri", "मेरे" to "mere",
            "तेरा" to "tera", "तेरी" to "teri", "तेरे" to "tere",
            "हमारा" to "hamara", "हमारी" to "hamari", "हमारे" to "hamare",
            "या" to "ya", "तो" to "toh", "भी" to "bhi", "ही" to "hi", "तक" to "tak",
            "धीरे-धीरे" to "dheere-dheere", "धीरे" to "dheere", "तेज़" to "tez",
            "हज़ारों" to "hazaaron", "हजारों" to "hazaaron", "लाखों" to "laakhon",
            "सितारों" to "sitaaron", "तारे" to "taare", "शानदार" to "shaandaar",
            "रोशनी" to "roshni", "अंधेरा" to "andhera", "प्यार" to "pyaar", "खतरा" to "khatra",
            "तुरंत" to "turant", "जल्दी" to "jaldi", "शुरू" to "shuru", "पूरा" to "poora",
            "मुश्किल" to "mushkil", "आसान" to "aasaan", "ज़्यादातर" to "zyadatar", "लगभग" to "lagbhag",
            "हमेशा" to "hamesha", "कभी" to "kabhi", "फिर" to "phir", "वापस" to "waapas",
            "अचानक" to "achanak", "शायद" to "shayad", "बिल्कुल" to "bilkul", "सिर्फ" to "sirf"
        )
    }
}
