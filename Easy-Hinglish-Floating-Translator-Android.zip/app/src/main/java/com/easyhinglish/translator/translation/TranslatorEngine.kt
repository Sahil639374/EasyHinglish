package com.easyhinglish.translator.translation

import com.easyhinglish.translator.model.DictionaryEntry
import com.easyhinglish.translator.model.OcrTextBlock
import com.easyhinglish.translator.model.TranslatedOverlayBlock
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.model.TranslationResult
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslatorEngine {
    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.HINDI)
        .build()

    private var clientInstance: com.google.mlkit.nl.translate.Translator? = null
    private val client: com.google.mlkit.nl.translate.Translator
        get() = clientInstance ?: Translation.getClient(options).also { clientInstance = it }

    @Volatile
    private var modelReady = false
    private val downloadStarted = AtomicBoolean(false)

    suspend fun isHindiPackDownloaded(): Boolean {
        if (modelReady) return true
        return suspendCancellableCoroutine { cont ->
            val model = TranslateRemoteModel.Builder(TranslateLanguage.HINDI).build()
            RemoteModelManager.getInstance().isModelDownloaded(model)
                .addOnSuccessListener { downloaded ->
                    if (downloaded) modelReady = true
                    if (cont.isActive) cont.resume(downloaded)
                }
                .addOnFailureListener {
                    if (cont.isActive) cont.resume(false)
                }
        }
    }

    fun startBackgroundModelDownload() {
        if (modelReady || !downloadStarted.compareAndSet(false, true)) return
        runCatching {
            val conditions = DownloadConditions.Builder().build()
            client.downloadModelIfNeeded(conditions)
                .addOnSuccessListener { modelReady = true }
                .addOnFailureListener { downloadStarted.set(false) }
        }.onFailure {
            downloadStarted.set(false)
        }
    }

    suspend fun ensureModelReady() {
        if (modelReady) return
        val conditions = DownloadConditions.Builder().build()
        suspendCancellableCoroutine<Unit> { cont ->
            client.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    modelReady = true
                    if (cont.isActive) cont.resume(Unit)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    private suspend fun translateWithMlKit(cleaned: String): String {
        return suspendCancellableCoroutine { cont ->
            client.translate(cleaned)
                .addOnSuccessListener { result ->
                    if (cont.isActive) cont.resume(result)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    private suspend fun translateRawHindi(cleaned: String): String {
        // Tier 1: Use ML Kit offline pack immediately if already downloaded
        if (isHindiPackDownloaded()) {
            val mlResult = runCatching { translateWithMlKit(cleaned) }.getOrNull()
            if (!mlResult.isNullOrBlank()) return mlResult
        } else {
            // Kick off background offline pack download without blocking the user
            startBackgroundModelDownload()
        }

        // Tier 2: Instant free HTTPS Google Translate (dict-chrome-ex)
        val c5 = withContext(Dispatchers.IO) {
            runCatching { translateInChunks(cleaned, 900, ::fetchGoogleClients5) }.getOrNull()
        }
        if (!c5.isNullOrBlank()) return c5

        // Tier 3: Backup Google Translate gtx endpoint
        val gtx = withContext(Dispatchers.IO) {
            runCatching { translateInChunks(cleaned, 900, ::fetchGoogleGtx) }.getOrNull()
        }
        if (!gtx.isNullOrBlank()) return gtx

        // Tier 4: Free MyMemory endpoint
        val mm = withContext(Dispatchers.IO) {
            runCatching { translateInChunks(cleaned, 420, ::fetchMyMemory) }.getOrNull()
        }
        if (!mm.isNullOrBlank()) return mm

        // Tier 5: Local zero-network phrase fallback so popup still opens cleanly offline
        return offlineLocalFallback(cleaned)
    }

    private fun translateInChunks(
        text: String,
        maxChunkChars: Int,
        fetcher: (String) -> String?
    ): String? {
        if (text.length <= maxChunkChars) return fetcher(text)
        val lines = text.split("\n")
        val chunks = mutableListOf<String>()
        val current = StringBuilder()
        for (line in lines) {
            if (current.isNotEmpty() && current.length + line.length + 1 > maxChunkChars) {
                chunks.add(current.toString())
                current.clear()
            }
            if (line.length > maxChunkChars) {
                if (current.isNotEmpty()) {
                    chunks.add(current.toString())
                    current.clear()
                }
                chunks.add(line.take(maxChunkChars))
            } else {
                if (current.isNotEmpty()) current.append('\n')
                current.append(line)
            }
        }
        if (current.isNotEmpty()) chunks.add(current.toString())

        val out = StringBuilder()
        for (chunk in chunks) {
            val translated = fetcher(chunk) ?: return null
            if (out.isNotEmpty()) out.append('\n')
            out.append(translated)
        }
        return out.toString().trim().takeIf { it.isNotEmpty() }
    }

    private fun fetchGoogleClients5(query: String): String? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=en&tl=hi&q=$encoded")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 7000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (!body.startsWith("[")) return null
            val arr = JSONArray(body)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val item = arr.opt(i)
                when (item) {
                    is String -> sb.append(item)
                    is JSONArray -> sb.append(item.optString(0, ""))
                }
            }
            sb.toString().trim().takeIf { it.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchGoogleGtx(query: String): String? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=hi&dt=t&q=$encoded")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 7000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            if (!body.startsWith("[")) return null
            val root = JSONArray(body)
            val sentences = root.optJSONArray(0) ?: return null
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                sb.append(sentences.optJSONArray(i)?.optString(0, "").orEmpty())
            }
            sb.toString().trim().takeIf { it.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchMyMemory(query: String): String? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://api.mymemory.translated.net/get?q=$encoded&langpair=en|hi")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 7000
            requestMethod = "GET"
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            val obj = JSONObject(body)
            val status = obj.optInt("responseStatus", 0)
            if (status != 200) return null
            obj.optJSONObject("responseData")?.optString("translatedText", "")?.trim()
                ?.takeIf { it.isNotEmpty() }
        } finally {
            conn.disconnect()
        }
    }

    private fun offlineLocalFallback(text: String): String {
        val wordMap = mapOf(
            "wait a minute" to "एक मिनट रुको",
            "we need your help" to "हमें आपकी मदद चाहिए",
            "right away" to "तुरंत",
            "problem" to "समस्या",
            "help" to "मदद",
            "settings" to "सेटिंग्स",
            "download" to "डाउनलोड",
            "search" to "खोजें",
            "continue" to "जारी रखें",
            "cancel" to "रद्द करें",
            "confirm" to "पक्का करें",
            "start" to "शुरू करें",
            "next" to "अगला",
            "back" to "वापस",
            "open" to "खोलें",
            "close" to "बंद करें",
            "save" to "सेव करें"
        )
        var out = text
        for ((en, hi) in wordMap) {
            out = out.replace(Regex("\\b${Regex.escape(en)}\\b", RegexOption.IGNORE_CASE), hi)
        }
        return out
    }

    fun formatHindiForMode(
        rawHindi: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): Pair<String, List<String>> {
        val applied = mutableListOf<String>()
        val useDevanagari = mode == TranslationMode.EASY_HINDI
        var processed = rawHindi

        for (entry in dictionary) {
            if (!entry.enabled || entry.sourceWord.isBlank() || entry.easyWord.isBlank()) continue
            val target = if (useDevanagari && entry.devanagariEasy.isNotBlank()) {
                entry.devanagariEasy
            } else {
                entry.easyWord
            }
            if (processed.contains(entry.sourceWord, ignoreCase = true)) {
                processed = processed.replace(entry.sourceWord, target, ignoreCase = true)
                applied.add("${entry.sourceWord} -> $target")
            }
        }

        val finalOutput = when (mode) {
            TranslationMode.EASY_HINDI -> processed
            TranslationMode.ROMAN_HINDI -> transliterateToRoman(processed)
            TranslationMode.HINGLISH -> buildHinglish(transliterateToRoman(processed))
        }
        return finalOutput to applied
    }

    suspend fun translateWithRaw(
        englishText: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): Pair<String, TranslationResult> {
        val cleaned = englishText.trim()
        if (cleaned.isEmpty()) {
            return "" to TranslationResult("", "", mode, emptyList())
        }
        val rawHindi = translateRawHindi(cleaned)
        val (finalOutput, applied) = formatHindiForMode(rawHindi, mode, dictionary)
        return rawHindi to TranslationResult(
            sourceText = cleaned,
            translatedText = finalOutput,
            mode = mode,
            appliedRules = applied
        )
    }

    suspend fun translate(
        englishText: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): TranslationResult {
        return translateWithRaw(englishText, mode, dictionary).second
    }

    suspend fun translateBlocks(
        blocks: List<OcrTextBlock>,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): List<TranslatedOverlayBlock> {
        val out = mutableListOf<TranslatedOverlayBlock>()
        for (block in blocks) {
            val clean = block.text.replace(Regex("\\s+"), " ").trim()
            if (clean.length < 2) continue
            val rawHindi = runCatching { translateRawHindi(clean) }.getOrNull() ?: continue
            val (formatted, _) = formatHindiForMode(rawHindi, mode, dictionary)
            if (formatted.isNotBlank()) {
                out.add(
                    TranslatedOverlayBlock(
                        sourceText = clean,
                        rawHindiText = rawHindi,
                        translatedText = formatted,
                        left = block.left,
                        top = block.top,
                        right = block.right,
                        bottom = block.bottom
                    )
                )
            }
        }
        return out
    }

    fun close() {
        runCatching { clientInstance?.close() }
        clientInstance = null
    }

    private fun buildHinglish(roman: String): String {
        val replacements = listOf(
            Regex("\\bpareshani\\b", RegexOption.IGNORE_CASE) to "problem",
            Regex("\\bjaankari\\b", RegexOption.IGNORE_CASE) to "details",
            Regex("\\bkoshish\\b", RegexOption.IGNORE_CASE) to "try",
            Regex("\\bsamay\\b", RegexOption.IGNORE_CASE) to "time",
            Regex("\\bshakti\\b", RegexOption.IGNORE_CASE) to "power",
            Regex("\\bkhatarnak\\b", RegexOption.IGNORE_CASE) to "dangerous",
            Regex("\\bsandesh\\b", RegexOption.IGNORE_CASE) to "message",
            Regex("\\bkripya\\b", RegexOption.IGNORE_CASE) to "please",
            Regex("\\bshukriya\\b", RegexOption.IGNORE_CASE) to "thanks"
        )
        var out = roman
        for ((regex, word) in replacements) {
            out = out.replace(regex, word)
        }
        return out
    }

    private fun transliterateToRoman(input: String): String {
        val common = listOf(
            "मैं" to "main", "हूँ" to "hoon", "हूं" to "hoon", "है" to "hai", "हैं" to "hain",
            "था" to "tha", "थी" to "thi", "थे" to "the", "थीं" to "theen",
            "नहीं" to "nahi", "और" to "aur", "में" to "mein", "पर" to "par", "से" to "se",
            "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke", "ने" to "ne",
            "यह" to "yeh", "वह" to "woh", "ये" to "ye", "वो" to "wo",
            "इस" to "is", "उस" to "us", "एक" to "ek", "दो" to "do",
            "आप" to "aap", "तुम" to "tum", "हम" to "hum", "क्या" to "kya", "क्यों" to "kyon",
            "बहुत" to "bahut", "ज़्यादा" to "zyada", "ज्यादा" to "zyada",
            "मदद" to "madad", "ज़रूरी" to "zaroori", "जरूरी" to "zaroori",
            "परेशानी" to "pareshani", "इंतज़ार" to "intezaar", "इंतजार" to "intezaar",
            "कृपया" to "kripya", "धन्यवाद" to "dhanyawad", "शुक्रिया" to "shukriya",
            "अपने" to "apne", "अपनी" to "apni", "अपना" to "apna",
            "साथ" to "saath", "छोटे" to "chhote", "छोटा" to "chhota", "छोटी" to "chhoti",
            "बड़े" to "bade", "बड़ा" to "bada", "बड़ी" to "badi",
            "गाँव" to "gaanv", "गांव" to "gaanv", "परिवार" to "parivar", "दोस्त" to "dost",
            "रहा" to "raha", "रही" to "rahi", "रहे" to "rahe",
            "रहता" to "rehta", "रहती" to "rehti", "रहते" to "rehte",
            "करता" to "karta", "करती" to "karti", "करते" to "karte",
            "गया" to "gaya", "गयी" to "gayi", "गई" to "gayi", "गए" to "gaye",
            "लिया" to "liya", "दिया" to "diya", "किया" to "kiya", "हुआ" to "hua", "हुई" to "hui",
            "सकता" to "sakta", "सकती" to "sakti", "सकते" to "sakte",
            "चाहिए" to "chahiye", "लेकिन" to "lekin", "क्योंकि" to "kyunki",
            "अगर" to "agar", "जब" to "jab", "तब" to "tab", "अभी" to "abhi",
            "यहाँ" to "yahan", "यहां" to "yahan", "वहाँ" to "wahan", "वहां" to "wahan",
            "कहाँ" to "kahan", "कहां" to "kahan", "कैसे" to "kaise", "कौन" to "kaun",
            "कुछ" to "kuch", "कोई" to "koi", "सभी" to "sabhi", "सब" to "sab",
            "अच्छा" to "achha", "अच्छे" to "achhe", "अच्छी" to "achhi",
            "लोग" to "log", "बात" to "baat", "दिन" to "din", "रात" to "raat",
            "नाम" to "naam", "काम" to "kaam", "पैसा" to "paisa", "पैसे" to "paise",
            "समय" to "samay", "रास्ता" to "raasta", "स्कूल" to "school",
            "कहानी" to "kahani", "लड़का" to "ladka", "लड़की" to "ladki",
            "आदमी" to "aadmi", "बूढ़े" to "boodhe", "बूढ़ा" to "boodha",
            "ईमानदार" to "imaandar", "मिला" to "mila", "देखा" to "dekha",
            "उठाया" to "uthaya", "खोला" to "khola", "सोचा" to "socha", "बोला" to "bola", "पूछा" to "poocha",
            "उसने" to "usne", "उसमें" to "usmein", "उसे" to "use", "उसको" to "usko", "उसका" to "uska",
            "मेरा" to "mera", "मेरी" to "meri", "मेरे" to "mere", "इसके" to "iske", "इसका" to "iska",
            "सारा" to "saara", "सारी" to "saari", "रास्ते" to "raaste", "सड़क" to "sadak",
            "थैला" to "thaila", "हैरान" to "hairan", "रह" to "reh", "मालिक" to "maalik",
            "ढूंढना" to "dhoondhna", "ढूँढना" to "dhoondhna", "चिंतित" to "chintit",
            "शुरुआती" to "shuruati", "आसान" to "aasaan", "कठिन" to "mushkil", "सरल" to "aasaan",
            "अंग्रेज़ी" to "English", "अंग्रेजी" to "English", "शब्दों" to "shabdon", "प्रयोग" to "istemal"
        )

        val preBuilder = StringBuilder()
        var idx = 0
        while (idx < input.length) {
            var matched = false
            for ((hi, ro) in common) {
                if (input.startsWith(hi, idx)) {
                    val beforeOk = idx == 0 || !isDevanagari(input[idx - 1])
                    val afterIdx = idx + hi.length
                    val afterOk = afterIdx >= input.length || !isDevanagari(input[afterIdx])
                    if (beforeOk && afterOk) {
                        preBuilder.append(ro)
                        idx = afterIdx
                        matched = true
                        break
                    }
                }
            }
            if (!matched) {
                preBuilder.append(input[idx])
                idx++
            }
        }
        val pre = preBuilder.toString()

        val digraphs = listOf(
            "क्ष" to "ksh", "त्र" to "tr", "ज्ञ" to "gy", "श्र" to "shr",
            "ज़" to "z", "फ़" to "f", "क़" to "q", "ख़" to "kh", "ग़" to "gh", "ड़" to "d", "ढ़" to "dh"
        )
        val consonants = mapOf(
            'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
            'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
            'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
            'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
            'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
            'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
            'ष' to "sh", 'स' to "s", 'ह' to "h"
        )
        val vowels = mapOf(
            'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo",
            'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o"
        )
        val matras = mapOf(
            'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo",
            'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
            'ॉ' to "o", 'ॅ' to "e",
            'ं' to "n", 'ँ' to "n", 'ः' to "h", '्' to ""
        )

        val sb = StringBuilder()
        var i = 0
        while (i < pre.length) {
            var matchedDigraph = false
            for ((dg, romanBase) in digraphs) {
                if (pre.startsWith(dg, i)) {
                    val afterPos = i + dg.length
                    val next = pre.getOrNull(afterPos)
                    if (next == '्') {
                        sb.append(romanBase)
                        i = afterPos + 1
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(romanBase).append(matras[next])
                        i = afterPos + 1
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-।"
                        sb.append(romanBase)
                        if (!isEnd) sb.append('a')
                        i = afterPos
                    }
                    matchedDigraph = true
                    break
                }
            }
            if (matchedDigraph) continue

            val ch = pre[i]
            when {
                ch == '।' -> sb.append('.')
                vowels.containsKey(ch) -> sb.append(vowels[ch])
                consonants.containsKey(ch) -> {
                    val base = consonants[ch]!!
                    val next = pre.getOrNull(i + 1)
                    if (next == '्') {
                        sb.append(base)
                        i++
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(base).append(matras[next])
                        i++
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-।"
                        sb.append(base)
                        if (!isEnd) sb.append('a')
                    }
                }
                matras.containsKey(ch) -> sb.append(matras[ch])
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString()
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun isDevanagari(c: Char): Boolean = c in '\u0900'..'\u097F'
}
