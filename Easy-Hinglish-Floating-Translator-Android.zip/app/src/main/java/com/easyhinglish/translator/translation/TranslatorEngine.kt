package com.easyhinglish.translator.translation

import com.easyhinglish.translator.model.DictionaryEntry
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.model.TranslationResult
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslatorEngine {
    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.HINDI)
        .build()

    private val client = Translation.getClient(options)
    private var modelReady = false

    suspend fun ensureModelReady() {
        if (modelReady) return
        val conditions = DownloadConditions.Builder().build()
        suspendCancellableCoroutine<Unit> { cont ->
            client.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    modelReady = true
                    if (cont.isActive) cont.resume(Unit)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    suspend fun translate(
        englishText: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): TranslationResult {
        val cleaned = englishText.trim()
        if (cleaned.isEmpty()) {
            return TranslationResult("", "", mode, emptyList())
        }

        ensureModelReady()
        val rawHindi = suspendCancellableCoroutine<String> { cont ->
            client.translate(cleaned)
                .addOnSuccessListener { result ->
                    if (cont.isActive) cont.resume(result)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }

        val applied = mutableListOf<String>()
        val useDevanagari = mode == TranslationMode.EASY_HINDI
        var processed = rawHindi

        for (entry in dictionary) {
            if (!entry.enabled || entry.sourceWord.isBlank() || entry.easyWord.isBlank()) continue
            val target = if (useDevanagari && entry.devanagariEasy.isNotBlank()) {
                entry.devanagariEasy
            } else {
                entry.easyWord
            }
            if (processed.contains(entry.sourceWord, ignoreCase = true)) {
                processed = processed.replace(entry.sourceWord, target, ignoreCase = true)
                applied.add("${entry.sourceWord} → $target")
            }
        }

        val finalOutput = when (mode) {
            TranslationMode.EASY_HINDI -> processed
            TranslationMode.ROMAN_HINDI -> transliterateToRoman(processed)
            TranslationMode.HINGLISH -> buildHinglish(transliterateToRoman(processed))
        }

        return TranslationResult(
            sourceText = cleaned,
            translatedText = finalOutput,
            mode = mode,
            appliedRules = applied
        )
    }

    fun close() {
        client.close()
    }

    private fun buildHinglish(roman: String): String {
        val replacements = listOf(
            Regex("\\bpareshani\\b", RegexOption.IGNORE_CASE) to "problem",
            Regex("\\bjaankari\\b", RegexOption.IGNORE_CASE) to "details",
            Regex("\\bkoshish\\b", RegexOption.IGNORE_CASE) to "try",
            Regex("\\bsamay\\b", RegexOption.IGNORE_CASE) to "time",
            Regex("\\bshakti\\b", RegexOption.IGNORE_CASE) to "power",
            Regex("\\bkhatarnak\\b", RegexOption.IGNORE_CASE) to "dangerous",
            Regex("\\bsandesh\\b", RegexOption.IGNORE_CASE) to "message",
            Regex("\\bkripya\\b", RegexOption.IGNORE_CASE) to "please",
            Regex("\\bshukriya\\b", RegexOption.IGNORE_CASE) to "thanks"
        )
        var out = roman
        for ((regex, word) in replacements) {
            out = out.replace(regex, word)
        }
        return out
    }

    private fun transliterateToRoman(input: String): String {
        val common = listOf(
            "मैं" to "main", "हूँ" to "hoon", "हूं" to "hoon", "है" to "hai", "हैं" to "hain",
            "नहीं" to "nahi", "और" to "aur", "में" to "mein", "पर" to "par", "से" to "se",
            "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke", "यह" to "yeh", "वह" to "woh",
            "आप" to "aap", "तुम" to "tum", "हम" to "hum", "क्या" to "kya", "बहुत" to "bahut",
            "मदद" to "madad", "ज़रूरी" to "zaroori", "जरूरी" to "zaroori",
            "परेशानी" to "pareshani", "इंतज़ार" to "intezaar", "इंतजार" to "intezaar",
            "ज़्यादा" to "zyada", "ज्यादा" to "zyada", "कृपया" to "kripya", "धन्यवाद" to "shukriya"
        )
        var pre = input
        for ((hi, ro) in common) {
            pre = pre.replace(hi, ro)
        }

        val consonants = mapOf(
            'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
            'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
            'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
            'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
            'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
            'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
            'ष' to "sh", 'स' to "s", 'ह' to "h", 'ज़' to "z", 'फ़' to "f"
        )
        val vowels = mapOf(
            'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo",
            'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au"
        )
        val matras = mapOf(
            'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo",
            'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
            'ं' to "n", 'ँ' to "n", 'ः' to "h", '्' to ""
        )

        val sb = StringBuilder()
        var i = 0
        while (i < pre.length) {
            val ch = pre[i]
            when {
                ch == '।' -> sb.append('.')
                vowels.containsKey(ch) -> sb.append(vowels[ch])
                consonants.containsKey(ch) -> {
                    val base = consonants[ch]!!
                    val next = pre.getOrNull(i + 1)
                    if (next == '्') {
                        sb.append(base)
                        i++
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(base).append(matras[next])
                        i++
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-"
                        sb.append(base)
                        if (!isEnd) sb.append('a')
                    }
                }
                matras.containsKey(ch) -> sb.append(matras[ch])
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }
}
