package com.easyhinglish.translator.translation

import com.easyhinglish.translator.model.DictionaryEntry
import com.easyhinglish.translator.model.OcrTextBlock
import com.easyhinglish.translator.model.TranslatedOverlayBlock
import com.easyhinglish.translator.model.TranslationMode
import com.easyhinglish.translator.model.TranslationResult
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TranslatorEngine {
    private val options = TranslatorOptions.Builder()
        .setSourceLanguage(TranslateLanguage.ENGLISH)
        .setTargetLanguage(TranslateLanguage.HINDI)
        .build()

    private var clientInstance: com.google.mlkit.nl.translate.Translator? = null
    private val client: com.google.mlkit.nl.translate.Translator
        get() = clientInstance ?: Translation.getClient(options).also { clientInstance = it }
    private var modelReady = false

    suspend fun ensureModelReady() {
        if (modelReady) return
        val conditions = DownloadConditions.Builder().build()
        suspendCancellableCoroutine<Unit> { cont ->
            client.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    modelReady = true
                    if (cont.isActive) cont.resume(Unit)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    private suspend fun translateRawHindi(cleaned: String): String {
        ensureModelReady()
        return suspendCancellableCoroutine { cont ->
            client.translate(cleaned)
                .addOnSuccessListener { result ->
                    if (cont.isActive) cont.resume(result)
                }
                .addOnFailureListener { ex ->
                    if (cont.isActive) cont.resumeWithException(ex)
                }
        }
    }

    fun formatHindiForMode(
        rawHindi: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): Pair<String, List<String>> {
        val applied = mutableListOf<String>()
        val useDevanagari = mode == TranslationMode.EASY_HINDI
        var processed = rawHindi

        for (entry in dictionary) {
            if (!entry.enabled || entry.sourceWord.isBlank() || entry.easyWord.isBlank()) continue
            val target = if (useDevanagari && entry.devanagariEasy.isNotBlank()) {
                entry.devanagariEasy
            } else {
                entry.easyWord
            }
            if (processed.contains(entry.sourceWord, ignoreCase = true)) {
                processed = processed.replace(entry.sourceWord, target, ignoreCase = true)
                applied.add("${entry.sourceWord} -> $target")
            }
        }

        val finalOutput = when (mode) {
            TranslationMode.EASY_HINDI -> processed
            TranslationMode.ROMAN_HINDI -> transliterateToRoman(processed)
            TranslationMode.HINGLISH -> buildHinglish(transliterateToRoman(processed))
        }
        return finalOutput to applied
    }

    suspend fun translate(
        englishText: String,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): TranslationResult {
        val cleaned = englishText.trim()
        if (cleaned.isEmpty()) {
            return TranslationResult("", "", mode, emptyList())
        }
        val rawHindi = translateRawHindi(cleaned)
        val (finalOutput, applied) = formatHindiForMode(rawHindi, mode, dictionary)
        return TranslationResult(
            sourceText = cleaned,
            translatedText = finalOutput,
            mode = mode,
            appliedRules = applied
        )
    }

    suspend fun translateBlocks(
        blocks: List<OcrTextBlock>,
        mode: TranslationMode,
        dictionary: List<DictionaryEntry>
    ): List<TranslatedOverlayBlock> {
        ensureModelReady()
        val out = mutableListOf<TranslatedOverlayBlock>()
        for (block in blocks) {
            val clean = block.text.replace(Regex("\\s+"), " ").trim()
            if (clean.length < 2) continue
            val rawHindi = runCatching { translateRawHindi(clean) }.getOrNull() ?: continue
            val (formatted, _) = formatHindiForMode(rawHindi, mode, dictionary)
            if (formatted.isNotBlank()) {
                out.add(
                    TranslatedOverlayBlock(
                        sourceText = clean,
                        rawHindiText = rawHindi,
                        translatedText = formatted,
                        left = block.left,
                        top = block.top,
                        right = block.right,
                        bottom = block.bottom
                    )
                )
            }
        }
        return out
    }

    fun close() {
        runCatching { clientInstance?.close() }
        clientInstance = null
    }

    private fun buildHinglish(roman: String): String {
        val replacements = listOf(
            Regex("\\bpareshani\\b", RegexOption.IGNORE_CASE) to "problem",
            Regex("\\bjaankari\\b", RegexOption.IGNORE_CASE) to "details",
            Regex("\\bkoshish\\b", RegexOption.IGNORE_CASE) to "try",
            Regex("\\bsamay\\b", RegexOption.IGNORE_CASE) to "time",
            Regex("\\bshakti\\b", RegexOption.IGNORE_CASE) to "power",
            Regex("\\bkhatarnak\\b", RegexOption.IGNORE_CASE) to "dangerous",
            Regex("\\bsandesh\\b", RegexOption.IGNORE_CASE) to "message",
            Regex("\\bkripya\\b", RegexOption.IGNORE_CASE) to "please",
            Regex("\\bshukriya\\b", RegexOption.IGNORE_CASE) to "thanks"
        )
        var out = roman
        for ((regex, word) in replacements) {
            out = out.replace(regex, word)
        }
        return out
    }

    private fun transliterateToRoman(input: String): String {
        val common = listOf(
            "मैं" to "main", "हूँ" to "hoon", "हूं" to "hoon", "है" to "hai", "हैं" to "hain",
            "था" to "tha", "थी" to "thi", "थे" to "the", "थीं" to "theen",
            "नहीं" to "nahi", "और" to "aur", "में" to "mein", "पर" to "par", "से" to "se",
            "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke", "ने" to "ne",
            "यह" to "yeh", "वह" to "woh", "ये" to "ye", "वो" to "wo",
            "इस" to "is", "उस" to "us", "एक" to "ek", "दो" to "do",
            "आप" to "aap", "तुम" to "tum", "हम" to "hum", "क्या" to "kya", "क्यों" to "kyon",
            "बहुत" to "bahut", "ज़्यादा" to "zyada", "ज्यादा" to "zyada",
            "मदद" to "madad", "ज़रूरी" to "zaroori", "जरूरी" to "zaroori",
            "परेशानी" to "pareshani", "इंतज़ार" to "intezaar", "इंतजार" to "intezaar",
            "कृपया" to "kripya", "धन्यवाद" to "dhanyawad", "शुक्रिया" to "shukriya",
            "अपने" to "apne", "अपनी" to "apni", "अपना" to "apna",
            "साथ" to "saath", "छोटे" to "chhote", "छोटा" to "chhota", "छोटी" to "chhoti",
            "बड़े" to "bade", "बड़ा" to "bada", "बड़ी" to "badi",
            "गाँव" to "gaanv", "गांव" to "gaanv", "परिवार" to "parivar", "दोस्त" to "dost",
            "रहा" to "raha", "रही" to "rahi", "रहे" to "rahe",
            "रहता" to "rehta", "रहती" to "rehti", "रहते" to "rehte",
            "करता" to "karta", "करती" to "karti", "करते" to "karte",
            "गया" to "gaya", "गयी" to "gayi", "गई" to "gayi", "गए" to "gaye",
            "लिया" to "liya", "दिया" to "diya", "किया" to "kiya", "हुआ" to "hua", "हुई" to "hui",
            "सकता" to "sakta", "सकती" to "sakti", "सकते" to "sakte",
            "चाहिए" to "chahiye", "लेकिन" to "lekin", "क्योंकि" to "kyunki",
            "अगर" to "agar", "जब" to "jab", "तब" to "tab", "अभी" to "abhi",
            "यहाँ" to "yahan", "यहां" to "yahan", "वहाँ" to "wahan", "वहां" to "wahan",
            "कहाँ" to "kahan", "कहां" to "kahan", "कैसे" to "kaise", "कौन" to "kaun",
            "कुछ" to "kuch", "कोई" to "koi", "सभी" to "sabhi", "सब" to "sab",
            "अच्छा" to "achha", "अच्छे" to "achhe", "अच्छी" to "achhi",
            "लोग" to "log", "बात" to "baat", "दिन" to "din", "रात" to "raat",
            "नाम" to "naam", "काम" to "kaam", "पैसा" to "paisa", "पैसे" to "paise",
            "समय" to "samay", "रास्ता" to "raasta", "स्कूल" to "school",
            "कहानी" to "kahani", "लड़का" to "ladka", "लड़की" to "ladki",
            "आदमी" to "aadmi", "बूढ़े" to "boodhe", "बूढ़ा" to "boodha",
            "ईमानदार" to "imaandar", "मिला" to "mila", "देखा" to "dekha",
            "उठाया" to "uthaya", "खोला" to "khola", "सोचा" to "socha", "बोला" to "bola", "पूछा" to "poocha"
        )

        val preBuilder = StringBuilder()
        var idx = 0
        while (idx < input.length) {
            var matched = false
            // Match known whole words on boundaries or multi-char clusters
            for ((hi, ro) in common) {
                if (input.startsWith(hi, idx)) {
                    val beforeOk = idx == 0 || !isDevanagari(input[idx - 1])
                    val afterIdx = idx + hi.length
                    val afterOk = afterIdx >= input.length || !isDevanagari(input[afterIdx])
                    if (beforeOk && afterOk) {
                        preBuilder.append(ro)
                        idx = afterIdx
                        matched = true
                        break
                    }
                }
            }
            if (!matched) {
                preBuilder.append(input[idx])
                idx++
            }
        }
        val pre = preBuilder.toString()

        val digraphs = listOf(
            "क्ष" to "ksh", "त्र" to "tr", "ज्ञ" to "gy", "श्र" to "shr",
            "ज़" to "z", "फ़" to "f", "क़" to "q", "ख़" to "kh", "ग़" to "gh", "ड़" to "d", "ढ़" to "dh"
        )
        val consonants = mapOf(
            'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
            'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
            'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
            'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
            'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
            'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
            'ष' to "sh", 'स' to "s", 'ह' to "h"
        )
        val vowels = mapOf(
            'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo",
            'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o"
        )
        val matras = mapOf(
            'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo",
            'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
            'ॉ' to "o", 'ॅ' to "e",
            'ं' to "n", 'ँ' to "n", 'ः' to "h", '्' to ""
        )

        val sb = StringBuilder()
        var i = 0
        while (i < pre.length) {
            var matchedDigraph = false
            for ((dg, romanBase) in digraphs) {
                if (pre.startsWith(dg, i)) {
                    val afterPos = i + dg.length
                    val next = pre.getOrNull(afterPos)
                    if (next == '्') {
                        sb.append(romanBase)
                        i = afterPos + 1
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(romanBase).append(matras[next])
                        i = afterPos + 1
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-।"
                        sb.append(romanBase)
                        if (!isEnd) sb.append('a')
                        i = afterPos
                    }
                    matchedDigraph = true
                    break
                }
            }
            if (matchedDigraph) continue

            val ch = pre[i]
            when {
                ch == '।' -> sb.append('.')
                vowels.containsKey(ch) -> sb.append(vowels[ch])
                consonants.containsKey(ch) -> {
                    val base = consonants[ch]!!
                    val next = pre.getOrNull(i + 1)
                    if (next == '्') {
                        sb.append(base)
                        i++
                    } else if (next != null && matras.containsKey(next) && next != 'ं' && next != 'ँ' && next != 'ः') {
                        sb.append(base).append(matras[next])
                        i++
                    } else {
                        val isEnd = next == null || next.isWhitespace() || next in ".,!?;:()\"'-।"
                        sb.append(base)
                        if (!isEnd) sb.append('a')
                    }
                }
                matras.containsKey(ch) -> sb.append(matras[ch])
                else -> sb.append(ch)
            }
            i++
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun isDevanagari(c: Char): Boolean = c in '\u0900'..'\u097F'
}
