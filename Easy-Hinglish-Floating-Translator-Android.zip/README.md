# Easy Hinglish Floating Translator — Mobile-Only APK Build & Install Guide (Simple Hindi)

## 1. Free APK Build (बिना PC, सिर्फ Infinix GT 20 Pro से)
1. Chrome में `github.com` पर Free Account बनाएं और एक **Public Repository** बनाएं (नाम: `Easy-Hinglish-Floating-Translator`)।
2. इस प्रोजेक्ट की `.github/workflows/build-apk.yml` और `android-app/` की सभी फाइलें अपनी GitHub Repository में अपलोड करें।
3. GitHub पर **Actions** टैब खोलें → **Build Easy Hinglish Translator APK** चुनें → **Run workflow** दबाएं (या push करते ही अपने आप शुरू हो जाएगा)।
4. 2–3 मिनट में Green Tick आने पर नीचे **Artifacts** से `Easy-Hinglish-Floating-Translator-APK` डाउनलोड करें।

## 2. Infinix GT 20 Pro (Android 16) पर APK Install करने के स्टेप्स
1. फोन के **Files** ऐप से डाउनलोड की गई ZIP को Extract करें।
2. `app-debug.apk` पर टैप करके **Install** करें (अगर पूछे तो Chrome/Files के लिए **Allow from this source** ऑन करें)।
3. ऐप खोलकर Settings टैब में:
   - **Allow Display Over Other Apps** ऑन करें।
   - **Set Battery Unrestricted** चुनें (ताकि Genshin Impact खेलते समय सिस्टम फ्लोटिंग बबल बंद न करे)।
   - **Start Floating Bubble Over Games** दबाएं और Screen OCR के लिए Screen Capture की अनुमति दें।

## 3. Future Updates कैसे करें
- जब भी कोई नया फीचर या शब्द बदलना हो, GitHub मोबाइल ऐप या ब्राउज़र से फाइल एडिट करके **Commit changes** करें।
- **Actions** टैब में अपने आप नया APK बन जाएगा, जिसे आप डाउनलोड करके पुराने ऐप के ऊपर सीधे अपडेट कर सकते हैं।
